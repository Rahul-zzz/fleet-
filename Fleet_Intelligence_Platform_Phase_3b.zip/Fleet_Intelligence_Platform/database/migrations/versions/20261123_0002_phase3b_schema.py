"""phase 3b: database schema, status seed data and append-only protections

Revision ID: 0002
Revises: 0001
Create Date: 2026-11-23

Creates every Phase 3b table, constraint and index, seeds the approved status
definitions (and one alias per definition) and installs the triggers that make
audit and correction history append-only and protect historical records from
deletion.

This migration is self-contained on purpose (it does not import application code), so
it keeps working even if the models change later. Constraint and index names follow
the project naming convention (see app/database/base.py).
"""
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql

# revision identifiers, used by Alembic.
revision: str = "0002"
down_revision: Union[str, None] = "0001"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


# --------------------------------------------------------------------------- helpers
def _pk(table: str, column: str = "id") -> sa.PrimaryKeyConstraint:
    return sa.PrimaryKeyConstraint(column, name=op.f(f"pk_{table}"))


def _fk(table: str, column: str, ref_table: str, ref_column: str = "id") -> sa.ForeignKeyConstraint:
    # Every foreign key is RESTRICT: historical rows are never cascade-deleted.
    return sa.ForeignKeyConstraint(
        [column],
        [f"{ref_table}.{ref_column}"],
        name=op.f(f"fk_{table}_{column}_{ref_table}"),
        ondelete="RESTRICT",
    )


def _ck(table: str, name: str, expression: str) -> sa.CheckConstraint:
    return sa.CheckConstraint(expression, name=op.f(f"ck_{table}_{name}"))


def _uq(name: str, *columns: str) -> sa.UniqueConstraint:
    return sa.UniqueConstraint(*columns, name=name)


def _uuid_id() -> sa.Column:
    return sa.Column(
        "id", sa.Uuid(), server_default=sa.text("gen_random_uuid()"), nullable=False
    )


def _bigint_id() -> sa.Column:
    return sa.Column("id", sa.BigInteger(), sa.Identity(), nullable=False)


def _int_id() -> sa.Column:
    return sa.Column("id", sa.Integer(), sa.Identity(), nullable=False)


def _created_at() -> sa.Column:
    return sa.Column(
        "created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False
    )


def _updated_at() -> sa.Column:
    return sa.Column(
        "updated_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False
    )


def _now_column(name: str) -> sa.Column:
    return sa.Column(name, sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False)


def _bool(name: str, default: str) -> sa.Column:
    return sa.Column(name, sa.Boolean(), server_default=sa.text(default), nullable=False)


# Tables created by this migration, in dependency order (parents first).
TABLES = [
    "users",
    "import_profiles",
    "status_definitions",
    "status_aliases",
    "status_definition_history",
    "uploaded_files",
    "reports",
    "import_raw_rows",
    "import_issues",
    "vehicles",
    "report_vehicles",
    "daily_km",
    "daily_status",
    "monthly_financials",
    "data_corrections",
    "vehicle_metrics",
    "report_metrics",
    "ai_conversations",
    "ai_messages",
    "ai_reports",
    "settings",
    "audit_log",
]

# Approved default statuses: (code, display name, category, sort order, description)
STATUS_SEED = [
    ("running", "Running", "utilized", 10, None),
    ("empty_running", "Empty Running", "utilized", 20, None),
    ("unloading", "Unloading", "utilized", 30, None),
    ("load_allotted", "Load Allotted", "utilized", 40, None),
    ("waiting_for_dispatch", "Waiting for Dispatch", "utilized", 50, None),
    ("waiting_for_load", "Waiting for Load", "unutilized", 60, None),
    ("under_maintenance", "Under Maintenance", "unutilized", 70, None),
    ("accident", "Accident", "unutilized", 80, None),
    ("halting", "Halting", "unutilized", 90, None),
    ("no_driver_assigned", "No Driver Assigned", "unutilized", 100, None),
    (
        "driver_home",
        "Driver Home",
        "unclassified",
        110,
        "Unclassified until the company confirms its classification.",
    ),
]

# Tables whose rows may never be updated or deleted (history / original imported data).
APPEND_ONLY_TABLES = [
    "audit_log",
    "data_corrections",
    "status_definition_history",
    "import_raw_rows",
    "daily_km",
    "daily_status",
]

# Tables whose rows may not be deleted (they may still be edited where designed).
NO_DELETE_TABLES = [
    "users",
    "import_profiles",
    "uploaded_files",
    "reports",
    "vehicles",
    "report_vehicles",
    "status_definitions",
    "status_aliases",
    "monthly_financials",
]


# ------------------------------------------------------------------------- upgrade
def upgrade() -> None:
    # --- A. users -----------------------------------------------------------------
    op.create_table(
        "users",
        _uuid_id(),
        sa.Column("email", sa.String(length=320), nullable=False),
        sa.Column("full_name", sa.String(length=200), nullable=False),
        sa.Column("password_hash", sa.String(length=255), nullable=False),
        sa.Column("role", sa.String(length=20), server_default=sa.text("'analyst'"), nullable=False),
        _bool("is_active", "true"),
        sa.Column("failed_login_count", sa.Integer(), server_default=sa.text("0"), nullable=False),
        sa.Column("locked_until", sa.DateTime(timezone=True), nullable=True),
        sa.Column("last_login_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("password_changed_at", sa.DateTime(timezone=True), nullable=True),
        _created_at(),
        _updated_at(),
        _pk("users"),
        _uq("uq_users_email", "email"),
        _ck("users", "email_lowercase", "email = lower(email)"),
        _ck("users", "role", "role IN ('admin', 'analyst')"),
        _ck(
            "users",
            "password_hash_format",
            r"password_hash ~ '^\$[a-z0-9]+\$' AND length(password_hash) >= 40",
        ),
        _ck("users", "failed_login_count_nonnegative", "failed_login_count >= 0"),
    )

    # --- B. import profiles --------------------------------------------------------
    op.create_table(
        "import_profiles",
        _uuid_id(),
        sa.Column("name", sa.String(length=150), nullable=False),
        sa.Column("version", sa.Integer(), server_default=sa.text("1"), nullable=False),
        sa.Column("description", sa.Text(), nullable=True),
        sa.Column(
            "config",
            postgresql.JSONB(astext_type=sa.Text()),
            server_default=sa.text("'{}'::jsonb"),
            nullable=False,
        ),
        _bool("is_active", "true"),
        sa.Column("created_by_user_id", sa.Uuid(), nullable=True),
        _created_at(),
        _updated_at(),
        _pk("import_profiles"),
        _fk("import_profiles", "created_by_user_id", "users"),
        _uq("uq_import_profiles_name_version", "name", "version"),
        _ck("import_profiles", "version_positive", "version >= 1"),
    )

    # --- F. status definitions ------------------------------------------------------
    op.create_table(
        "status_definitions",
        _int_id(),
        sa.Column("code", sa.String(length=50), nullable=False),
        sa.Column("display_name", sa.String(length=100), nullable=False),
        sa.Column("category", sa.String(length=20), nullable=False),
        sa.Column("sort_order", sa.SmallInteger(), server_default=sa.text("0"), nullable=False),
        _bool("is_active", "true"),
        _bool("is_system", "false"),
        sa.Column("description", sa.Text(), nullable=True),
        _created_at(),
        _updated_at(),
        _pk("status_definitions"),
        _uq("uq_status_definitions_code", "code"),
        _uq("uq_status_definitions_display_name", "display_name"),
        _ck("status_definitions", "code_format", "code ~ '^[a-z0-9_]+$'"),
        _ck(
            "status_definitions",
            "category",
            "category IN ('utilized', 'unutilized', 'unclassified')",
        ),
    )
    op.create_table(
        "status_aliases",
        _int_id(),
        sa.Column("status_definition_id", sa.Integer(), nullable=False),
        sa.Column("alias_normalized", sa.String(length=100), nullable=False),
        sa.Column("alias_display", sa.String(length=100), nullable=False),
        _bool("is_active", "true"),
        sa.Column("created_by_user_id", sa.Uuid(), nullable=True),
        _created_at(),
        _updated_at(),
        _pk("status_aliases"),
        _fk("status_aliases", "status_definition_id", "status_definitions"),
        _fk("status_aliases", "created_by_user_id", "users"),
        _uq("uq_status_aliases_alias_normalized", "alias_normalized"),
        _ck(
            "status_aliases",
            "alias_normalized_format",
            "alias_normalized = lower(btrim(alias_normalized)) AND length(alias_normalized) > 0",
        ),
    )
    op.create_index(
        "ix_status_aliases_status_definition_id", "status_aliases", ["status_definition_id"]
    )
    op.create_table(
        "status_definition_history",
        _bigint_id(),
        sa.Column("status_definition_id", sa.Integer(), nullable=False),
        sa.Column("field_name", sa.String(length=50), nullable=False),
        sa.Column("old_value", sa.String(length=100), nullable=True),
        sa.Column("new_value", sa.String(length=100), nullable=True),
        sa.Column("changed_by_user_id", sa.Uuid(), nullable=True),
        sa.Column("reason", sa.Text(), nullable=True),
        _created_at(),
        _pk("status_definition_history"),
        _fk("status_definition_history", "status_definition_id", "status_definitions"),
        _fk("status_definition_history", "changed_by_user_id", "users"),
    )
    op.create_index(
        "ix_status_definition_history_definition_created",
        "status_definition_history",
        ["status_definition_id", "created_at"],
    )

    # --- B. uploaded files ----------------------------------------------------------
    op.create_table(
        "uploaded_files",
        _uuid_id(),
        sa.Column("original_filename", sa.String(length=512), nullable=False),
        sa.Column("file_extension", sa.String(length=10), nullable=False),
        sa.Column("content_type", sa.String(length=255), nullable=True),
        sa.Column("size_bytes", sa.BigInteger(), nullable=False),
        sa.Column("sha256", sa.String(length=64), nullable=False),
        sa.Column("storage_ref", sa.String(length=1024), nullable=False),
        sa.Column("status", sa.String(length=20), server_default=sa.text("'uploaded'"), nullable=False),
        sa.Column("contains_macros", sa.Boolean(), nullable=True),
        sa.Column("import_profile_id", sa.Uuid(), nullable=True),
        sa.Column("declared_year", sa.SmallInteger(), nullable=True),
        sa.Column("declared_month", sa.SmallInteger(), nullable=True),
        sa.Column("file_metadata", postgresql.JSONB(astext_type=sa.Text()), nullable=True),
        sa.Column("uploaded_by_user_id", sa.Uuid(), nullable=False),
        _now_column("uploaded_at"),
        _created_at(),
        _updated_at(),
        _pk("uploaded_files"),
        _fk("uploaded_files", "import_profile_id", "import_profiles"),
        _fk("uploaded_files", "uploaded_by_user_id", "users"),
        _uq("uq_uploaded_files_sha256", "sha256"),
        _ck("uploaded_files", "file_extension", "file_extension IN ('.xlsx', '.xlsm')"),
        _ck("uploaded_files", "sha256_format", "sha256 ~ '^[0-9a-f]{64}$'"),
        _ck("uploaded_files", "size_bytes_positive", "size_bytes > 0"),
        _ck(
            "uploaded_files",
            "status",
            "status IN ('uploaded', 'analyzed', 'committed', 'rejected', 'failed')",
        ),
        _ck(
            "uploaded_files",
            "declared_month_range",
            "declared_month IS NULL OR declared_month BETWEEN 1 AND 12",
        ),
        _ck(
            "uploaded_files",
            "declared_year_range",
            "declared_year IS NULL OR declared_year BETWEEN 2000 AND 2100",
        ),
        _ck(
            "uploaded_files",
            "declared_period_complete",
            "(declared_year IS NULL) = (declared_month IS NULL)",
        ),
    )
    op.create_index("ix_uploaded_files_uploaded_by_user_id", "uploaded_files", ["uploaded_by_user_id"])
    op.create_index("ix_uploaded_files_status", "uploaded_files", ["status"])

    # --- B. reports -----------------------------------------------------------------
    op.create_table(
        "reports",
        _uuid_id(),
        sa.Column("year", sa.SmallInteger(), nullable=False),
        sa.Column("month", sa.SmallInteger(), nullable=False),
        sa.Column("version", sa.Integer(), server_default=sa.text("1"), nullable=False),
        sa.Column("status", sa.String(length=20), server_default=sa.text("'draft'"), nullable=False),
        _bool("is_current", "false"),
        sa.Column("days_in_month", sa.SmallInteger(), nullable=False),
        sa.Column("source_file_id", sa.Uuid(), nullable=False),
        sa.Column("import_profile_id", sa.Uuid(), nullable=True),
        sa.Column("supersedes_report_id", sa.Uuid(), nullable=True),
        sa.Column("superseded_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("replacement_reason", sa.Text(), nullable=True),
        sa.Column("confirmed_by_user_id", sa.Uuid(), nullable=True),
        sa.Column("confirmed_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("notes", sa.Text(), nullable=True),
        _created_at(),
        _updated_at(),
        _pk("reports"),
        _fk("reports", "source_file_id", "uploaded_files"),
        _fk("reports", "import_profile_id", "import_profiles"),
        _fk("reports", "supersedes_report_id", "reports"),
        _fk("reports", "confirmed_by_user_id", "users"),
        _uq("uq_reports_year_month_version", "year", "month", "version"),
        _ck("reports", "month_range", "month BETWEEN 1 AND 12"),
        _ck("reports", "year_range", "year BETWEEN 2000 AND 2100"),
        _ck("reports", "version_positive", "version >= 1"),
        _ck("reports", "days_in_month_range", "days_in_month BETWEEN 28 AND 31"),
        _ck("reports", "status", "status IN ('draft', 'active', 'superseded', 'failed')"),
        _ck("reports", "current_must_be_active", "NOT is_current OR status = 'active'"),
        _ck(
            "reports",
            "superseded_consistency",
            "(status = 'superseded') = (superseded_at IS NOT NULL)",
        ),
        _ck(
            "reports",
            "not_self_superseding",
            "supersedes_report_id IS NULL OR supersedes_report_id <> id",
        ),
    )
    op.create_index(
        "uq_reports_current_year_month",
        "reports",
        ["year", "month"],
        unique=True,
        postgresql_where=sa.text("is_current"),
    )
    op.create_index("ix_reports_source_file_id", "reports", ["source_file_id"])
    op.create_index("ix_reports_supersedes_report_id", "reports", ["supersedes_report_id"])

    # --- B. raw rows and issues -----------------------------------------------------
    op.create_table(
        "import_raw_rows",
        _bigint_id(),
        sa.Column("uploaded_file_id", sa.Uuid(), nullable=False),
        sa.Column("sheet_name", sa.String(length=255), nullable=False),
        sa.Column("row_number", sa.Integer(), nullable=False),
        sa.Column("payload", postgresql.JSONB(astext_type=sa.Text()), nullable=False),
        _created_at(),
        _pk("import_raw_rows"),
        _fk("import_raw_rows", "uploaded_file_id", "uploaded_files"),
        _uq("uq_import_raw_rows_file_sheet_row", "uploaded_file_id", "sheet_name", "row_number"),
        _ck("import_raw_rows", "row_number_positive", "row_number >= 1"),
    )
    op.create_table(
        "import_issues",
        _bigint_id(),
        sa.Column("uploaded_file_id", sa.Uuid(), nullable=False),
        sa.Column("report_id", sa.Uuid(), nullable=True),
        sa.Column("severity", sa.String(length=10), nullable=False),
        sa.Column("code", sa.String(length=100), nullable=False),
        sa.Column("message", sa.Text(), nullable=False),
        sa.Column("sheet_name", sa.String(length=255), nullable=True),
        sa.Column("row_number", sa.Integer(), nullable=True),
        sa.Column("column_ref", sa.String(length=50), nullable=True),
        sa.Column("raw_value", sa.Text(), nullable=True),
        sa.Column("details", postgresql.JSONB(astext_type=sa.Text()), nullable=True),
        _created_at(),
        _pk("import_issues"),
        _fk("import_issues", "uploaded_file_id", "uploaded_files"),
        _fk("import_issues", "report_id", "reports"),
        _ck("import_issues", "severity", "severity IN ('info', 'warning', 'error')"),
    )
    op.create_index("ix_import_issues_file_severity", "import_issues", ["uploaded_file_id", "severity"])
    op.create_index("ix_import_issues_report_id", "import_issues", ["report_id"])
    op.create_index("ix_import_issues_code", "import_issues", ["code"])

    # --- C. vehicles ----------------------------------------------------------------
    op.create_table(
        "vehicles",
        _uuid_id(),
        sa.Column("reg_no", sa.String(length=20), nullable=False),
        sa.Column("route", sa.String(length=200), nullable=True),
        sa.Column("vehicle_type", sa.String(length=100), nullable=True),
        _bool("is_active", "true"),
        sa.Column("notes", sa.Text(), nullable=True),
        _created_at(),
        _updated_at(),
        _pk("vehicles"),
        _uq("uq_vehicles_reg_no", "reg_no"),
        _ck("vehicles", "reg_no_canonical", "reg_no ~ '^[A-Z0-9]{4,20}$'"),
    )
    op.create_table(
        "report_vehicles",
        _uuid_id(),
        sa.Column("report_id", sa.Uuid(), nullable=False),
        sa.Column("vehicle_id", sa.Uuid(), nullable=False),
        sa.Column("reg_no_as_imported", sa.String(length=50), nullable=False),
        sa.Column("route", sa.String(length=200), nullable=True),
        sa.Column("vehicle_type", sa.String(length=100), nullable=True),
        sa.Column("source_sheet", sa.String(length=255), nullable=True),
        sa.Column("source_row", sa.Integer(), nullable=True),
        sa.Column("remarks", sa.Text(), nullable=True),
        sa.Column("attributes", postgresql.JSONB(astext_type=sa.Text()), nullable=True),
        _created_at(),
        _pk("report_vehicles"),
        _fk("report_vehicles", "report_id", "reports"),
        _fk("report_vehicles", "vehicle_id", "vehicles"),
        _uq("uq_report_vehicles_report_id_vehicle_id", "report_id", "vehicle_id"),
    )
    op.create_index("ix_report_vehicles_vehicle_id", "report_vehicles", ["vehicle_id"])

    # --- D. daily data --------------------------------------------------------------
    op.create_table(
        "daily_km",
        _bigint_id(),
        sa.Column("report_vehicle_id", sa.Uuid(), nullable=False),
        sa.Column("reading_date", sa.Date(), nullable=False),
        sa.Column("source_text", sa.Text(), nullable=True),
        sa.Column("km", sa.Numeric(precision=10, scale=2), nullable=True),
        sa.Column("data_state", sa.String(length=20), nullable=False),
        sa.Column("source_sheet", sa.String(length=255), nullable=True),
        sa.Column("source_row", sa.Integer(), nullable=True),
        sa.Column("source_column", sa.String(length=20), nullable=True),
        _created_at(),
        _pk("daily_km"),
        _fk("daily_km", "report_vehicle_id", "report_vehicles"),
        _uq("uq_daily_km_report_vehicle_id_reading_date", "report_vehicle_id", "reading_date"),
        _ck(
            "daily_km",
            "data_state",
            "data_state IN ('actual', 'reported_zero', 'gps_offline', 'missing', 'invalid')",
        ),
        _ck(
            "daily_km",
            "km_matches_state",
            "(data_state = 'actual' AND km IS NOT NULL AND km > 0)"
            " OR (data_state = 'reported_zero' AND km IS NOT NULL AND km = 0)"
            " OR (data_state IN ('gps_offline', 'missing', 'invalid') AND km IS NULL)",
        ),
    )
    op.create_index("ix_daily_km_reading_date_state", "daily_km", ["reading_date", "data_state"])
    op.create_table(
        "daily_status",
        _bigint_id(),
        sa.Column("report_vehicle_id", sa.Uuid(), nullable=False),
        sa.Column("status_date", sa.Date(), nullable=False),
        sa.Column("source_text", sa.Text(), nullable=True),
        sa.Column("match_state", sa.String(length=20), nullable=False),
        sa.Column("status_definition_id", sa.Integer(), nullable=True),
        sa.Column("matched_alias_id", sa.Integer(), nullable=True),
        sa.Column("source_sheet", sa.String(length=255), nullable=True),
        sa.Column("source_row", sa.Integer(), nullable=True),
        sa.Column("source_column", sa.String(length=20), nullable=True),
        _created_at(),
        _pk("daily_status"),
        _fk("daily_status", "report_vehicle_id", "report_vehicles"),
        _fk("daily_status", "status_definition_id", "status_definitions"),
        _fk("daily_status", "matched_alias_id", "status_aliases"),
        _uq("uq_daily_status_report_vehicle_id_status_date", "report_vehicle_id", "status_date"),
        _ck(
            "daily_status",
            "match_state",
            "match_state IN ('recognized', 'unrecognized', 'missing')",
        ),
        _ck(
            "daily_status",
            "definition_matches_state",
            "(match_state = 'recognized' AND status_definition_id IS NOT NULL"
            " AND source_text IS NOT NULL AND btrim(source_text) <> '')"
            " OR (match_state = 'unrecognized' AND status_definition_id IS NULL"
            " AND matched_alias_id IS NULL AND source_text IS NOT NULL AND btrim(source_text) <> '')"
            " OR (match_state = 'missing' AND status_definition_id IS NULL"
            " AND matched_alias_id IS NULL AND source_text IS NULL)",
        ),
    )
    op.create_index("ix_daily_status_status_date", "daily_status", ["status_date"])
    op.create_index("ix_daily_status_status_definition_id", "daily_status", ["status_definition_id"])

    # --- E. monthly financials ------------------------------------------------------
    op.create_table(
        "monthly_financials",
        _bigint_id(),
        sa.Column("report_vehicle_id", sa.Uuid(), nullable=False),
        sa.Column("revenue", sa.Numeric(precision=14, scale=2), nullable=True),
        sa.Column("erp_km", sa.Numeric(precision=12, scale=2), nullable=True),
        sa.Column("trips", sa.Integer(), nullable=True),
        sa.Column("cars_lifted", sa.Integer(), nullable=True),
        sa.Column("source_sheet", sa.String(length=255), nullable=True),
        sa.Column("source_values", postgresql.JSONB(astext_type=sa.Text()), nullable=True),
        _created_at(),
        _pk("monthly_financials"),
        _fk("monthly_financials", "report_vehicle_id", "report_vehicles"),
        _uq("uq_monthly_financials_report_vehicle_id", "report_vehicle_id"),
        _ck("monthly_financials", "revenue_nonnegative", "revenue IS NULL OR revenue >= 0"),
        _ck("monthly_financials", "erp_km_nonnegative", "erp_km IS NULL OR erp_km >= 0"),
        _ck("monthly_financials", "trips_nonnegative", "trips IS NULL OR trips >= 0"),
        _ck("monthly_financials", "cars_lifted_nonnegative", "cars_lifted IS NULL OR cars_lifted >= 0"),
    )

    # --- G. corrections -------------------------------------------------------------
    op.create_table(
        "data_corrections",
        _bigint_id(),
        sa.Column("report_id", sa.Uuid(), nullable=True),
        sa.Column("report_vehicle_id", sa.Uuid(), nullable=True),
        sa.Column("target_table", sa.String(length=50), nullable=False),
        sa.Column("target_id", sa.String(length=64), nullable=False),
        sa.Column("field_name", sa.String(length=100), nullable=False),
        sa.Column("original_value", postgresql.JSONB(astext_type=sa.Text()), nullable=True),
        sa.Column("corrected_value", postgresql.JSONB(astext_type=sa.Text()), nullable=True),
        sa.Column("reason", sa.Text(), nullable=False),
        sa.Column(
            "correction_type", sa.String(length=20), server_default=sa.text("'correction'"), nullable=False
        ),
        sa.Column("corrected_by_user_id", sa.Uuid(), nullable=False),
        _now_column("corrected_at"),
        sa.Column("reverses_correction_id", sa.BigInteger(), nullable=True),
        sa.Column("supersedes_correction_id", sa.BigInteger(), nullable=True),
        _pk("data_corrections"),
        _fk("data_corrections", "report_id", "reports"),
        _fk("data_corrections", "report_vehicle_id", "report_vehicles"),
        _fk("data_corrections", "corrected_by_user_id", "users"),
        _fk("data_corrections", "reverses_correction_id", "data_corrections"),
        _fk("data_corrections", "supersedes_correction_id", "data_corrections"),
        _uq("uq_data_corrections_reverses_correction_id", "reverses_correction_id"),
        _ck(
            "data_corrections",
            "target_table",
            "target_table IN ('daily_km', 'daily_status', 'report_vehicles',"
            " 'monthly_financials', 'vehicles')",
        ),
        _ck("data_corrections", "correction_type", "correction_type IN ('correction', 'reversal')"),
        _ck(
            "data_corrections",
            "reversal_links_original",
            "(correction_type = 'reversal') = (reverses_correction_id IS NOT NULL)",
        ),
        _ck("data_corrections", "reason_not_blank", "length(btrim(reason)) > 0"),
        _ck(
            "data_corrections",
            "not_self_reversing",
            "reverses_correction_id IS NULL OR reverses_correction_id <> id",
        ),
        _ck(
            "data_corrections",
            "not_self_superseding",
            "supersedes_correction_id IS NULL OR supersedes_correction_id <> id",
        ),
    )
    op.create_index("ix_data_corrections_target", "data_corrections", ["target_table", "target_id"])
    op.create_index("ix_data_corrections_report_vehicle_id", "data_corrections", ["report_vehicle_id"])
    op.create_index("ix_data_corrections_report_id", "data_corrections", ["report_id"])
    op.create_index("ix_data_corrections_corrected_at", "data_corrections", ["corrected_at"])
    op.create_index(
        "ix_data_corrections_corrected_by_user_id", "data_corrections", ["corrected_by_user_id"]
    )

    # --- G. metric records (structure only) -----------------------------------------
    op.create_table(
        "vehicle_metrics",
        _bigint_id(),
        sa.Column("report_vehicle_id", sa.Uuid(), nullable=False),
        sa.Column("calc_version", sa.String(length=50), nullable=False),
        sa.Column("metric_values", postgresql.JSONB(astext_type=sa.Text()), nullable=False),
        sa.Column("provenance", postgresql.JSONB(astext_type=sa.Text()), nullable=True),
        sa.Column("inputs_fingerprint", sa.String(length=64), nullable=True),
        _now_column("calculated_at"),
        _bool("is_current", "true"),
        sa.Column("invalidated_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("invalidation_reason", sa.Text(), nullable=True),
        _created_at(),
        _updated_at(),
        _pk("vehicle_metrics"),
        _fk("vehicle_metrics", "report_vehicle_id", "report_vehicles"),
        _ck("vehicle_metrics", "current_not_invalidated", "NOT is_current OR invalidated_at IS NULL"),
    )
    op.create_index(
        "uq_vehicle_metrics_current",
        "vehicle_metrics",
        ["report_vehicle_id"],
        unique=True,
        postgresql_where=sa.text("is_current"),
    )
    op.create_index(
        "ix_vehicle_metrics_report_vehicle_calc",
        "vehicle_metrics",
        ["report_vehicle_id", "calc_version"],
    )
    op.create_table(
        "report_metrics",
        _bigint_id(),
        sa.Column("report_id", sa.Uuid(), nullable=False),
        sa.Column("calc_version", sa.String(length=50), nullable=False),
        sa.Column("metric_values", postgresql.JSONB(astext_type=sa.Text()), nullable=False),
        sa.Column("provenance", postgresql.JSONB(astext_type=sa.Text()), nullable=True),
        sa.Column("inputs_fingerprint", sa.String(length=64), nullable=True),
        _now_column("calculated_at"),
        _bool("is_current", "true"),
        sa.Column("invalidated_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("invalidation_reason", sa.Text(), nullable=True),
        _created_at(),
        _updated_at(),
        _pk("report_metrics"),
        _fk("report_metrics", "report_id", "reports"),
        _ck("report_metrics", "current_not_invalidated", "NOT is_current OR invalidated_at IS NULL"),
    )
    op.create_index(
        "uq_report_metrics_current",
        "report_metrics",
        ["report_id"],
        unique=True,
        postgresql_where=sa.text("is_current"),
    )
    op.create_index("ix_report_metrics_report_calc", "report_metrics", ["report_id", "calc_version"])

    # --- H. AI preparation and settings ---------------------------------------------
    op.create_table(
        "ai_conversations",
        _uuid_id(),
        sa.Column("user_id", sa.Uuid(), nullable=False),
        sa.Column("title", sa.String(length=255), nullable=True),
        sa.Column("context_state", postgresql.JSONB(astext_type=sa.Text()), nullable=True),
        sa.Column("archived_at", sa.DateTime(timezone=True), nullable=True),
        _created_at(),
        _updated_at(),
        _pk("ai_conversations"),
        _fk("ai_conversations", "user_id", "users"),
    )
    op.create_index("ix_ai_conversations_user_id", "ai_conversations", ["user_id"])
    op.create_table(
        "ai_messages",
        _bigint_id(),
        sa.Column("conversation_id", sa.Uuid(), nullable=False),
        sa.Column("sequence", sa.Integer(), nullable=False),
        sa.Column("role", sa.String(length=20), nullable=False),
        sa.Column("channel", sa.String(length=10), server_default=sa.text("'text'"), nullable=False),
        sa.Column("content", sa.Text(), nullable=True),
        sa.Column("tool_calls", postgresql.JSONB(astext_type=sa.Text()), nullable=True),
        sa.Column("provider", sa.String(length=50), nullable=True),
        sa.Column("model", sa.String(length=100), nullable=True),
        sa.Column("token_usage", postgresql.JSONB(astext_type=sa.Text()), nullable=True),
        _created_at(),
        _pk("ai_messages"),
        _fk("ai_messages", "conversation_id", "ai_conversations"),
        _uq("uq_ai_messages_conversation_id_sequence", "conversation_id", "sequence"),
        _ck("ai_messages", "role", "role IN ('user', 'assistant', 'tool', 'system')"),
        _ck("ai_messages", "channel", "channel IN ('text', 'voice')"),
        _ck("ai_messages", "sequence_positive", "sequence >= 1"),
        _ck("ai_messages", "has_content", "content IS NOT NULL OR tool_calls IS NOT NULL"),
    )
    op.create_table(
        "ai_reports",
        _uuid_id(),
        sa.Column("report_id", sa.Uuid(), nullable=False),
        sa.Column("kind", sa.String(length=40), nullable=False),
        sa.Column("narrative", sa.Text(), nullable=False),
        sa.Column("source_figures", postgresql.JSONB(astext_type=sa.Text()), nullable=True),
        sa.Column("calc_version", sa.String(length=50), nullable=True),
        sa.Column("conversation_id", sa.Uuid(), nullable=True),
        sa.Column("generated_by_user_id", sa.Uuid(), nullable=True),
        sa.Column("provider", sa.String(length=50), nullable=True),
        sa.Column("model", sa.String(length=100), nullable=True),
        _created_at(),
        _pk("ai_reports"),
        _fk("ai_reports", "report_id", "reports"),
        _fk("ai_reports", "conversation_id", "ai_conversations"),
        _fk("ai_reports", "generated_by_user_id", "users"),
        _ck(
            "ai_reports",
            "kind",
            "kind IN ('monthly_utilization', 'vehicle_performance', 'unutilized_vehicle',"
            " 'fleet_efficiency', 'executive_summary')",
        ),
    )
    op.create_index("ix_ai_reports_report_id_kind", "ai_reports", ["report_id", "kind"])
    op.create_table(
        "settings",
        sa.Column("setting_key", sa.String(length=150), nullable=False),
        sa.Column("value", postgresql.JSONB(astext_type=sa.Text()), nullable=False),
        sa.Column("description", sa.Text(), nullable=True),
        sa.Column("updated_by_user_id", sa.Uuid(), nullable=True),
        _created_at(),
        _updated_at(),
        _pk("settings", "setting_key"),
        _fk("settings", "updated_by_user_id", "users"),
    )

    # --- A. audit log ---------------------------------------------------------------
    op.create_table(
        "audit_log",
        _bigint_id(),
        _now_column("occurred_at"),
        sa.Column("actor_user_id", sa.Uuid(), nullable=True),
        sa.Column("actor_email", sa.String(length=320), nullable=True),
        sa.Column("action", sa.String(length=100), nullable=False),
        sa.Column("entity_type", sa.String(length=100), nullable=False),
        sa.Column("entity_id", sa.String(length=100), nullable=True),
        sa.Column("before_data", postgresql.JSONB(astext_type=sa.Text()), nullable=True),
        sa.Column("after_data", postgresql.JSONB(astext_type=sa.Text()), nullable=True),
        sa.Column("details", postgresql.JSONB(astext_type=sa.Text()), nullable=True),
        sa.Column("ip_address", postgresql.INET(), nullable=True),
        sa.Column("request_id", sa.String(length=100), nullable=True),
        _pk("audit_log"),
        _fk("audit_log", "actor_user_id", "users"),
        _ck("audit_log", "action_not_blank", "length(btrim(action)) > 0"),
        _ck("audit_log", "entity_type_not_blank", "length(btrim(entity_type)) > 0"),
    )
    op.create_index("ix_audit_log_occurred_at", "audit_log", ["occurred_at"])
    op.create_index("ix_audit_log_entity", "audit_log", ["entity_type", "entity_id"])
    op.create_index(
        "ix_audit_log_actor_user_id_occurred_at", "audit_log", ["actor_user_id", "occurred_at"]
    )
    op.create_index("ix_audit_log_action", "audit_log", ["action"])

    # --- F. seed the approved status definitions (once; tables were just created) ----
    status_definitions = sa.table(
        "status_definitions",
        sa.column("code", sa.String),
        sa.column("display_name", sa.String),
        sa.column("category", sa.String),
        sa.column("sort_order", sa.SmallInteger),
        sa.column("is_system", sa.Boolean),
        sa.column("description", sa.Text),
    )
    op.bulk_insert(
        status_definitions,
        [
            {
                "code": code,
                "display_name": display_name,
                "category": category,
                "sort_order": sort_order,
                "is_system": True,
                "description": description,
            }
            for code, display_name, category, sort_order, description in STATUS_SEED
        ],
    )
    # One alias per definition: its own display name, normalized (lower case).
    op.execute(
        "INSERT INTO status_aliases (status_definition_id, alias_normalized, alias_display) "
        "SELECT id, lower(btrim(display_name)), display_name FROM status_definitions"
    )

    # --- Protect history ------------------------------------------------------------
    op.execute(
        """
        CREATE FUNCTION fleetiq_block_update_delete() RETURNS trigger
        LANGUAGE plpgsql AS $$
        BEGIN
            RAISE EXCEPTION 'Table % is append-only: % is not allowed', TG_TABLE_NAME, TG_OP
                USING ERRCODE = 'restrict_violation';
        END;
        $$
        """
    )
    op.execute(
        """
        CREATE FUNCTION fleetiq_block_delete() RETURNS trigger
        LANGUAGE plpgsql AS $$
        BEGIN
            RAISE EXCEPTION 'Rows of table % cannot be deleted', TG_TABLE_NAME
                USING ERRCODE = 'restrict_violation';
        END;
        $$
        """
    )
    for table in APPEND_ONLY_TABLES:
        op.execute(
            f"CREATE TRIGGER trg_{table}_append_only BEFORE UPDATE OR DELETE ON {table} "
            "FOR EACH ROW EXECUTE FUNCTION fleetiq_block_update_delete()"
        )
    for table in NO_DELETE_TABLES:
        op.execute(
            f"CREATE TRIGGER trg_{table}_no_delete BEFORE DELETE ON {table} "
            "FOR EACH ROW EXECUTE FUNCTION fleetiq_block_delete()"
        )


# ----------------------------------------------------------------------- downgrade
def downgrade() -> None:
    # Dropping a table drops its triggers and indexes. Children are dropped before parents.
    for table in reversed(TABLES):
        op.drop_table(table)
    op.execute("DROP FUNCTION IF EXISTS fleetiq_block_delete()")
    op.execute("DROP FUNCTION IF EXISTS fleetiq_block_update_delete()")
