"""baseline (empty)

Revision ID: 0001
Revises:
Create Date: 2026-11-23

Phase 3a baseline. Creates no tables; it only establishes the Alembic version
history. The real schema arrives in Phase 3 as later revisions.
"""
from typing import Sequence, Union

# revision identifiers, used by Alembic.
revision: str = "0001"
down_revision: Union[str, None] = None
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    pass


def downgrade() -> None:
    pass
