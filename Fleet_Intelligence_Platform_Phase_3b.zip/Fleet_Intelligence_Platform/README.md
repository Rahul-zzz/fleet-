# FLEETIQ – Fleet Intelligence Platform

**Status: Phase 3b – database schema and backend foundation** (builds on the Phase 3a skeleton).
It adds the PostgreSQL schema, SQLAlchemy models, migration `0002`, seeded status
definitions and database services. There is still **no Excel ingestion, no metrics
calculation, no authentication, no dashboards and no AI**: those come in later phases.
The whole chain still works the same way:

```
React page (localhost:5173) → FastAPI (localhost:8000/api/v1) → PostgreSQL in Docker (127.0.0.1:5433)
```

## Prerequisites (Windows 10/11, PowerShell)

| Tool | Requirement |
|---|---|
| Python | 3.11 or newer (3.12 recommended) |
| Node.js | **22 LTS recommended; 20.19+ is the minimum** (current Vite does not run on Node 20.0–20.18) |
| npm | Installed with Node.js |
| Docker Desktop | Installed **and running** (provides PostgreSQL through Docker Compose) |

Check what you have:

```powershell
python --version
py --list
node --version
npm --version
docker --version
docker compose version
docker info --format "{{.ServerVersion}}"    # prints a version only if Docker Desktop is running
Get-NetTCPConnection -LocalPort 5433,8000,5173 -ErrorAction SilentlyContinue | Select-Object LocalPort,State,OwningProcess
```

Missing tools (reopen PowerShell afterwards):

```powershell
winget install -e --id Python.Python.3.12
winget install -e --id OpenJS.NodeJS.LTS
winget install -e --id Docker.DockerDesktop
```

A local PostgreSQL installation is **not** required. If the last command lists a process on
port 5433, 8000 or 5173, stop that program or tell me before continuing.

## 1. Environment files

From the project root (the folder that contains this README):

```powershell
Copy-Item .env.example .env
Copy-Item backend\.env.example backend\.env
Copy-Item frontend\.env.example frontend\.env
```

Edit the first two and replace `CHANGE_ME` with a password of your choice
(**letters and digits only**, the same in both files):

```powershell
notepad .env
notepad backend\.env
```

Then verify the files agree (it never prints the password):

```powershell
.\scripts\check-env.ps1
```

If PowerShell blocks the script:
`powershell -ExecutionPolicy Bypass -File .\scripts\check-env.ps1`

Notes:
- `backend\.env` uses `127.0.0.1`, not `localhost`: Docker publishes the port on IPv4 only.
- PostgreSQL takes its password **when the data volume is first created**. If you change the
  password later: `docker compose down -v` then `docker compose up -d` (this deletes the local database).

## 2. Start PostgreSQL

```powershell
docker compose up -d
docker compose ps
```

Expected: `fleetiq-db` is `running`, then `(healthy)` after a few seconds.
If not: `docker compose logs db`

## 3. Backend (FastAPI)

```powershell
cd backend
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements-dev.txt
```

If activation is blocked: `Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned`, then retry.

Apply the Alembic migrations (`0001` baseline, then `0002` which creates the Phase 3b schema):

```powershell
alembic upgrade head
alembic current
```

Expected: `alembic current` prints `0002 (head)`. Confirm in PostgreSQL (use your own user/database
names if you changed them):

```powershell
docker exec -it fleetiq-db psql -U fleetiq -d fleetiq -c "\dt"
```

Expected: 23 tables (the 22 FLEETIQ tables plus `alembic_version`). Details of the schema are in the
**Phase 3b: database** section below.

### Tests

```powershell
pytest -v -m "not integration"   # unit tests: no database needed
pytest -v -m integration         # integration tests: need PostgreSQL running AND `alembic upgrade head` applied
pytest -v                        # everything (needs PostgreSQL running and migrated)
```

Unit tests cover the normalization utilities, calendar handling, model structure, a comparison of
migration `0002` against the models, the status seed, and the Pydantic schemas. They need the
installed packages but **no database**.

Integration tests connect to the real PostgreSQL container and check that the database itself
rejects bad data (Offline/Missing stored as zero, duplicate vehicles, two current reports for one
month, plaintext passwords, edits to corrections/audit/original daily data, ...). Each test runs
in a transaction that is rolled back, so your data is untouched. If the container is stopped,
`backend\.env` does not match the root `.env`, or the migration was not applied, they fail.

### Run the API

```powershell
uvicorn app.main:app --reload --port 8000
```

In a second PowerShell window:

```powershell
Invoke-RestMethod http://localhost:8000/api/v1/health
Invoke-RestMethod http://localhost:8000/api/v1/health/db
```

API documentation: http://localhost:8000/docs

Health endpoints (all under `/api/v1/health`): `""` (API), `/db` (connectivity) and the new
`/schema` (migration state: current vs newest revision and table counts; no names or errors).

## 4. Frontend (React + TypeScript + Vite)

In a new PowerShell window, from the project root:

```powershell
cd frontend
npm install
npm run build
npm run dev
```

Open http://localhost:5173. You should see two cards, **Backend API** and **Database**,
both showing a green **Connected** badge (backend and database running).

Failure tests:
- Stop the backend (Ctrl+C), click **Re-run checks** → both cards turn red.
- With the backend running, `docker compose stop db` → Database card fails (HTTP 503), Backend API stays green.
  Restart with `docker compose start db`.

## Phase 3b: database

Full documentation with ER diagrams: [`documentation/database-schema.md`](documentation/database-schema.md).

### Migration commands (run in `backend` with the virtual environment active)

```powershell
alembic upgrade head             # create / update the schema (0001 -> 0002)
alembic current                  # expect: 0002 (head)
alembic history                  # 0001 baseline, 0002 phase 3b schema
alembic check                    # compares the models with the database; expect "No new upgrade operations detected."
alembic downgrade 0001           # DANGER: drops every Phase 3b table and the seed data
alembic upgrade head             # re-applies it (seed is inserted again exactly once)
```

`alembic check` is the most useful verification on your machine: it fails if the models and the
migration have drifted apart. If it reports differences, please send me the output.

Check the seed and tables directly:

```powershell
docker exec -it fleetiq-db psql -U fleetiq -d fleetiq -c "SELECT code, display_name, category FROM status_definitions ORDER BY sort_order;"
docker exec -it fleetiq-db psql -U fleetiq -d fleetiq -c "\dt"
```

Expected: 11 statuses (5 utilized, 5 unutilized, Driver Home unclassified) and 23 tables.

### Verify without a database (optional)

```powershell
python scripts\static_schema_check.py
```

Uses only the Python standard library. It checks that the models and migration `0002` agree
(tables, columns, types, foreign keys, constraints, indexes), that no foreign key cascades, that
the key CHECK rules accept and reject the right values, that the seed matches the approved list
and that the downgrade order is safe. It does **not** replace `alembic upgrade head`.

### The 22 tables

| Group | Tables |
|---|---|
| Security | `users`, `audit_log` |
| Files and reports | `uploaded_files`, `import_profiles`, `reports`, `import_raw_rows`, `import_issues` |
| Vehicles | `vehicles`, `report_vehicles` |
| Daily data | `daily_km`, `daily_status` |
| Source data | `monthly_financials` |
| Status configuration | `status_definitions`, `status_aliases`, `status_definition_history` |
| Corrections and metrics | `data_corrections`, `vehicle_metrics`, `report_metrics` |
| AI preparation | `ai_conversations`, `ai_messages`, `ai_reports`, `settings` |

### Things to know

- **Append-only protection.** Database triggers reject UPDATE and DELETE on `audit_log`,
  `data_corrections`, `status_definition_history`, `import_raw_rows`, `daily_km` and
  `daily_status`, and reject DELETE on reports, uploads, vehicles, users and similar tables.
  Original imported data is never edited: fixes are corrections and replacements are new report
  versions. `TRUNCATE` is not blocked. To reset your **local** database use
  `docker compose down -v` then `docker compose up -d` and `alembic upgrade head`.
- **Offline is not zero.** `daily_km.km` is NULL for `gps_offline`, `missing` and `invalid`;
  `0` is only valid for `reported_zero`.
- **Not Available is NULL.** Revenue, ERP km, trips and cars are never stored as 0 when unknown.
- **Status classification is data.** Change `status_definitions.category` through
  `StatusRepository.set_category` (it appends to `status_definition_history`). Unknown text is stored
  as `unrecognized`; nothing is classified automatically. "To be Sold" is not an official status.
- **No default settings yet.** `settings` is empty; thresholds are added when they are used.
- `users` stores only a password hash (the hashing code arrives with authentication in a later phase).

## Project layout

```
Fleet_Intelligence_Platform/
├─ docker-compose.yml        PostgreSQL 16 (127.0.0.1:5433)
├─ .env.example              Docker Compose settings (copy to .env)
├─ scripts/check-env.ps1     Verifies root .env and backend/.env agree
├─ scripts/static_schema_check.py   Offline models-vs-migration consistency check
├─ backend/                  FastAPI app, Alembic config, tests
│  └─ app/{api,core,models,repositories,schemas,services,data_processing,metrics,ai,voice,reports,database,utils}
│     models/ (22 tables) · repositories/ · schemas/ (Pydantic) · database/ (session, mixins, seed)
├─ database/migrations/      Alembic environment + versions (0001 baseline, 0002 phase 3b schema)
├─ frontend/                 React + TypeScript + Vite + Tailwind CSS
├─ uploads/                  Reserved for later phases (git-ignored)
└─ documentation/
```

Empty backend packages (`data_processing`, `metrics`, `ai`, `voice`, `reports`) and the empty
frontend folders are placeholders for later phases.

## Security notes

- `.env` files are git-ignored. Never commit them. This project contains no real passwords or API keys.
- PostgreSQL is bound to localhost only.
- `.xlsx` / `.xlsm` files and `uploads/` content are git-ignored.
