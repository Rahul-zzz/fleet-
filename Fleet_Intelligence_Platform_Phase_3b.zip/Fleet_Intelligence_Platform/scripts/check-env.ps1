# Verifies the root .env and backend\.env agree. Run from the project root:
#   .\scripts\check-env.ps1
# It never prints passwords.
$root = Join-Path $PSScriptRoot ".."
$rootEnv = Join-Path $root ".env"
$backendEnv = Join-Path $root "backend\.env"

foreach ($f in @($rootEnv, $backendEnv)) {
  if (-not (Test-Path $f)) { Write-Host "MISSING: $f" -ForegroundColor Red; exit 1 }
}

function Read-EnvFile($path) {
  $map = @{}
  Get-Content $path | ForEach-Object {
    if ($_ -match '^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)\s*$' -and -not $_.TrimStart().StartsWith('#')) {
      $map[$Matches[1]] = $Matches[2]
    }
  }
  $map
}

$r = Read-EnvFile $rootEnv
$b = Read-EnvFile $backendEnv

if (-not $b.ContainsKey("DATABASE_URL")) { Write-Host "DATABASE_URL missing in backend\.env" -ForegroundColor Red; exit 1 }
if ($r["POSTGRES_PASSWORD"] -eq "CHANGE_ME" -or $b["DATABASE_URL"] -match ':CHANGE_ME@') {
  Write-Host "Placeholder password CHANGE_ME is still in use. Set a real password in both files." -ForegroundColor Red
  exit 1
}

$uri = [System.Uri]($b["DATABASE_URL"] -replace '^postgresql\+psycopg', 'postgresql')
$userInfo = $uri.UserInfo.Split(':', 2)
$urlUser = [System.Uri]::UnescapeDataString($userInfo[0])
$urlPass = [System.Uri]::UnescapeDataString($userInfo[1])
$urlDb   = $uri.AbsolutePath.TrimStart('/')
$port    = if ($r["POSTGRES_PORT"]) { $r["POSTGRES_PORT"] } else { "5433" }

$checks = @(
  @("user",     $r["POSTGRES_USER"],     $urlUser),
  @("password", $r["POSTGRES_PASSWORD"], $urlPass),
  @("database", $r["POSTGRES_DB"],       $urlDb),
  @("port",     $port,                   "$($uri.Port)")
)

$ok = $true
foreach ($c in $checks) {
  if ($c[1] -ceq $c[2]) { Write-Host ("OK       {0}" -f $c[0]) -ForegroundColor Green }
  else { Write-Host ("MISMATCH {0} (root .env vs backend DATABASE_URL)" -f $c[0]) -ForegroundColor Red; $ok = $false }
}
if ($uri.Host -eq "localhost") {
  Write-Host "WARNING  host is 'localhost'; use 127.0.0.1 (IPv4) to match Docker's port binding" -ForegroundColor Yellow
}
if ($ok) { Write-Host "Configuration is consistent." -ForegroundColor Green } else { exit 1 }
