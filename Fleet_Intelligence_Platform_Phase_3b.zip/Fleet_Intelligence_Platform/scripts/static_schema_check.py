"""Offline schema consistency check (standard library only).

Why this exists: it lets you check, WITHOUT PostgreSQL, SQLAlchemy or Docker, that
  * the ORM models and Alembic migration 0002 describe the same schema,
  * foreign keys point at real columns and never cascade-delete,
  * the key CHECK constraints accept and reject exactly the intended values,
  * the status seed matches the approved list,
  * the downgrade drops everything in a safe order.

How it works: it imports the real models and the real migration against a tiny recording
stand-in for SQLAlchemy/Alembic. It therefore proves the files are consistent with EACH
OTHER. It does NOT prove they run on PostgreSQL. Use `alembic upgrade head`,
`alembic check` and `pytest` for that.

Usage (from the project root):   python scripts/static_schema_check.py
"""
from __future__ import annotations

import importlib.util
import re
import sys
import types
import typing
import uuid
from collections import OrderedDict
from decimal import Decimal
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BACKEND = ROOT / "backend"
MIGRATION = ROOT / "database" / "migrations" / "versions" / "20261123_0002_phase3b_schema.py"
BASELINE = ROOT / "database" / "migrations" / "versions" / "20261123_0001_baseline.py"

# ----------------------------------------------------------------------------------
# Recording stand-ins for sqlalchemy / alembic
# ----------------------------------------------------------------------------------


class SqlType:
    def __init__(self, *args, **kw):
        self.args = args
        self.kw = kw

    def key(self) -> str:
        name = type(self).__name__
        if name == "String":
            length = self.kw.get("length", self.args[0] if self.args else None)
            return f"String({length})"
        if name == "Numeric":
            p = self.kw.get("precision", self.args[0] if self.args else None)
            s = self.kw.get("scale", self.args[1] if len(self.args) > 1 else None)
            return f"Numeric({p},{s})"
        if name == "DateTime":
            return f"DateTime(tz={bool(self.kw.get('timezone', self.args[0] if self.args else False))})"
        return name


def _mk(name):
    return type(name, (SqlType,), {})


String, Integer, BigInteger, SmallInteger, Boolean, Date, Text, Numeric, Uuid, DateTime, JSONB, INET = (
    _mk(n)
    for n in (
        "String", "Integer", "BigInteger", "SmallInteger", "Boolean", "Date", "Text",
        "Numeric", "Uuid", "DateTime", "JSONB", "INET",
    )
)


def _as_type(x):
    if isinstance(x, type) and issubclass(x, SqlType):
        return x()
    return x if isinstance(x, SqlType) else None


class Identity:
    pass


class TextClause:
    def __init__(self, text):
        self.text = text


def text(s):
    return TextClause(s)


class _Func:
    def __getattr__(self, name):
        return lambda *a, **k: TextClause(f"{name}()")


func = _Func()


class ForeignKey:
    def __init__(self, target, ondelete=None, name=None, **kw):
        self.target, self.ondelete, self.name = target, ondelete, name


class CheckConstraint:
    def __init__(self, sqltext, name=None, **kw):
        self.sqltext = sqltext.text if isinstance(sqltext, TextClause) else sqltext
        self.name = name


class UniqueConstraint:
    def __init__(self, *columns, name=None, **kw):
        self.columns, self.name = list(columns), name


class PrimaryKeyConstraint:
    def __init__(self, *columns, name=None, **kw):
        self.columns, self.name = list(columns), name


class ForeignKeyConstraint:
    def __init__(self, columns, refcolumns, name=None, ondelete=None, **kw):
        self.columns, self.refcolumns, self.name, self.ondelete = (
            list(columns), list(refcolumns), name, ondelete,
        )


class Index:
    def __init__(self, name, *columns, unique=False, postgresql_where=None, **kw):
        self.name, self.columns, self.unique = name, list(columns), unique
        self.where = postgresql_where.text if isinstance(postgresql_where, TextClause) else postgresql_where


class MetaData:
    def __init__(self, naming_convention=None):
        self.naming_convention = naming_convention
        self.tables: "OrderedDict[str, dict]" = OrderedDict()


class Column:  # used by the migration (sa.Column)
    def __init__(self, name, *args, nullable=True, server_default=None, **kw):
        self.name = name
        self.type = None
        self.identity = False
        for a in args:
            if _as_type(a) is not None:
                self.type = _as_type(a)
            elif isinstance(a, Identity):
                self.identity = True
        self.nullable = nullable
        self.server_default = server_default


# ---- ORM side
class _Mapped:
    def __class_getitem__(cls, item):
        return _MappedAnn(item)


class _MappedAnn:
    def __init__(self, item):
        self.item = item

    def optional(self) -> bool:
        origin = typing.get_origin(self.item)
        if origin in (typing.Union, types.UnionType):
            return type(None) in typing.get_args(self.item)
        return self.item is typing.Any and False


class ColumnSpec:
    def __init__(self, *args, **kw):
        self.args, self.kw = args, kw


def mapped_column(*args, **kw):
    return ColumnSpec(*args, **kw)


def relationship(*args, **kw):
    return object()


class DeclarativeBase:
    metadata: MetaData

    def __init_subclass__(cls, **kw):
        super().__init_subclass__(**kw)
        if "__tablename__" not in cls.__dict__:
            return
        columns: "OrderedDict[str, tuple[ColumnSpec, object]]" = OrderedDict()
        for klass in reversed(cls.__mro__):
            ann = klass.__dict__.get("__annotations__", {})
            for attr, value in klass.__dict__.items():
                if isinstance(value, ColumnSpec):
                    columns[attr] = (value, ann.get(attr))
        args = cls.__dict__.get("__table_args__", ())
        cls.metadata.tables[cls.__tablename__] = {"columns": columns, "args": args}


def _install_fake_modules():
    sa = types.ModuleType("sqlalchemy")
    for n, v in dict(
        String=String, Integer=Integer, BigInteger=BigInteger, SmallInteger=SmallInteger,
        Boolean=Boolean, Date=Date, Text=Text, Numeric=Numeric, Uuid=Uuid, DateTime=DateTime,
        Identity=Identity, ForeignKey=ForeignKey, CheckConstraint=CheckConstraint,
        UniqueConstraint=UniqueConstraint, PrimaryKeyConstraint=PrimaryKeyConstraint,
        ForeignKeyConstraint=ForeignKeyConstraint, Index=Index, MetaData=MetaData,
        Column=Column, func=func, text=text,
    ).items():
        setattr(sa, n, v)

    def table(name, *cols):
        return ("table", name)

    sa.table = table
    sa.column = lambda name, type_=None: ("column", name)
    orm = types.ModuleType("sqlalchemy.orm")
    orm.Mapped, orm.mapped_column, orm.relationship = _Mapped, mapped_column, relationship
    orm.DeclarativeBase = DeclarativeBase
    dialects = types.ModuleType("sqlalchemy.dialects")
    pg = types.ModuleType("sqlalchemy.dialects.postgresql")
    pg.JSONB, pg.INET = JSONB, INET
    dialects.postgresql = pg
    sa.orm, sa.dialects = orm, dialects

    alembic = types.ModuleType("alembic")
    op = Recorder()
    alembic.op = op
    sys.modules.update({
        "sqlalchemy": sa, "sqlalchemy.orm": orm, "sqlalchemy.dialects": dialects,
        "sqlalchemy.dialects.postgresql": pg, "alembic": alembic,
    })
    return op


class Recorder:
    def __init__(self):
        self.reset()

    def reset(self):
        self.created: "OrderedDict[str, list]" = OrderedDict()
        self.indexes: list = []
        self.executed: list[str] = []
        self.bulk: list = []
        self.dropped: list[str] = []

    def f(self, name):
        return name

    def create_table(self, name, *items):
        self.created[name] = list(items)

    def create_index(self, name, table, columns, unique=False, postgresql_where=None):
        where = postgresql_where.text if isinstance(postgresql_where, TextClause) else postgresql_where
        self.indexes.append((name, table, list(columns), unique, where))

    def execute(self, sql):
        self.executed.append(sql if isinstance(sql, str) else str(sql))

    def bulk_insert(self, table, rows):
        self.bulk.append((table, rows))

    def drop_table(self, name):
        self.dropped.append(name)


# ----------------------------------------------------------------------------------
# Normalisers
# ----------------------------------------------------------------------------------


def norm_sql(s: str) -> str:
    return re.sub(r"\s+", " ", s.strip())


def norm_default(v) -> str | None:
    if v is None:
        return None
    s = v.text if isinstance(v, TextClause) else str(v)
    return s.strip().strip("'").lower()


# ----------------------------------------------------------------------------------
# Loading
# ----------------------------------------------------------------------------------

results: list[tuple[bool, str]] = []


def check(ok: bool, message: str) -> None:
    results.append((bool(ok), message))
    print(("PASS  " if ok else "FAIL  ") + message)


def load_models():
    sys.path.insert(0, str(BACKEND))
    import app.models  # noqa: F401  (registers tables on the stand-in Base)
    from app.database.base import Base

    model_tables = OrderedDict()
    for tname, spec in Base.metadata.tables.items():
        cols = OrderedDict()
        fks, checks, uniques, indexes = [], {}, {}, {}
        for cname, (cs, ann) in spec["columns"].items():
            fk = next((a for a in cs.args if isinstance(a, ForeignKey)), None)
            ctype = next((_as_type(a) for a in cs.args if _as_type(a) is not None), None)
            if ctype is None and ann is not None and getattr(ann, "item", None) is not None:
                inner = ann.item
                args = [a for a in typing.get_args(inner) if a is not type(None)] or [inner]
                if args[0] is uuid.UUID:
                    ctype = Uuid()
            pk = bool(cs.kw.get("primary_key"))
            if "nullable" in cs.kw:
                nullable = cs.kw["nullable"]
            elif pk:
                nullable = False
            else:
                nullable = ann.optional() if ann is not None else True
            cols[cname] = dict(
                type=ctype.key() if ctype else None,
                fk_inferred=ctype is None and fk is not None,
                nullable=nullable,
                identity=any(isinstance(a, Identity) for a in cs.args),
                default=norm_default(cs.kw.get("server_default")),
                pk=pk,
            )
            if fk is not None:
                fks.append((cname, fk.target, fk.ondelete))
        for item in spec["args"]:
            if isinstance(item, CheckConstraint):
                checks[f"ck_{tname}_{item.name}"] = norm_sql(item.sqltext)
            elif isinstance(item, UniqueConstraint):
                uniques[item.name] = item.columns
            elif isinstance(item, Index):
                indexes[item.name] = (item.columns, item.unique, item.where)
        model_tables[tname] = dict(cols=cols, fks=fks, checks=checks, uniques=uniques, indexes=indexes)
    return model_tables


def load_migration(op):
    spec = importlib.util.spec_from_file_location("migration_0002", MIGRATION)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    op.reset()
    module.upgrade()
    created, idx, executed, bulk = op.created, list(op.indexes), list(op.executed), list(op.bulk)
    op.reset()
    module.downgrade()
    dropped, down_exec = list(op.dropped), list(op.executed)
    mig = OrderedDict()
    for tname, items in created.items():
        cols, fks, checks, uniques, pk = OrderedDict(), [], {}, {}, []
        for it in items:
            if isinstance(it, Column):
                cols[it.name] = dict(
                    type=it.type.key() if it.type else None, nullable=it.nullable,
                    identity=it.identity, default=norm_default(it.server_default),
                )
            elif isinstance(it, PrimaryKeyConstraint):
                pk = it.columns
            elif isinstance(it, ForeignKeyConstraint):
                fks.append((it.columns[0], it.refcolumns[0], it.ondelete, it.name))
            elif isinstance(it, CheckConstraint):
                checks[it.name] = norm_sql(it.sqltext)
            elif isinstance(it, UniqueConstraint):
                uniques[it.name] = it.columns
        for c in pk:
            cols[c]["nullable"] = False
        mig[tname] = dict(cols=cols, fks=fks, checks=checks, uniques=uniques, pk=pk, indexes={})
    for name, table, columns, unique, where in idx:
        mig[table]["indexes"][name] = (columns, unique, where)
    return module, mig, dropped, executed, bulk, down_exec


# ----------------------------------------------------------------------------------
# Truth-table evaluation of CHECK constraints (subset of SQL -> Python)
# ----------------------------------------------------------------------------------


def sql_to_python(expr: str) -> str:
    e = expr
    e = re.sub(r"(\w+) IS NOT NULL", r"(\1 is not None)", e)
    e = re.sub(r"(\w+) IS NULL", r"(\1 is None)", e)
    e = re.sub(r"btrim\((\w+)\)", r"(\1).strip()", e)
    e = e.replace("length(", "len(")
    e = re.sub(r"\bAND\b", "and", e)
    e = re.sub(r"\bOR\b", "or", e)
    e = re.sub(r"\bNOT\b", "not", e)
    e = re.sub(r"\bIN\b", "in", e)
    e = e.replace("<>", "!=")
    e = re.sub(r"(?<![<>!=])=(?!=)", "==", e)
    return e


def evaluate(expr: str, **row) -> bool:
    return bool(eval(sql_to_python(expr), {"__builtins__": {"len": len}}, row))


def main() -> int:
    op = _install_fake_modules()
    model = load_models()
    module, mig, dropped, executed, bulk, down_exec = load_migration(op)

    # ---- tables
    check(set(model) == set(mig), f"models and migration define the same {len(model)} tables")
    check(list(mig) == module.TABLES, "migration TABLES list matches the creation order")
    check(
        len(model) == 22,
        "22 tables (spec entities + status_definition_history, the append-only status audit trail)",
    )

    # ---- columns, types, nullability, defaults, identity
    col_problems = []
    for t in sorted(set(model) & set(mig)):
        mc, gc = model[t]["cols"], mig[t]["cols"]
        if set(mc) != set(gc):
            col_problems.append(f"{t}: columns differ model-only={set(mc)-set(gc)} migration-only={set(gc)-set(mc)}")
            continue
        for c in mc:
            m, g = mc[c], gc[c]
            if not m["fk_inferred"] and m["type"] != g["type"]:
                col_problems.append(f"{t}.{c}: type {m['type']} vs {g['type']}")
            if m["nullable"] != g["nullable"]:
                col_problems.append(f"{t}.{c}: nullable {m['nullable']} vs {g['nullable']}")
            if m["identity"] != g["identity"]:
                col_problems.append(f"{t}.{c}: identity differs")
            if m["default"] != g["default"]:
                col_problems.append(f"{t}.{c}: server default {m['default']!r} vs {g['default']!r}")
        if sorted(c for c, v in mc.items() if v["pk"]) != sorted(mig[t]["pk"]):
            col_problems.append(f"{t}: primary key differs")
    check(not col_problems, "columns, types, nullability, defaults, identity and primary keys match" + (f" -> {col_problems[:8]}" if col_problems else ""))

    # ---- foreign keys
    fk_problems, fk_count = [], 0
    for t in sorted(set(model) & set(mig)):
        mset = {(c, tgt, od) for c, tgt, od in model[t]["fks"]}
        gset = {(c, tgt, od) for c, tgt, od, _ in mig[t]["fks"]}
        fk_count += len(gset)
        if mset != gset:
            fk_problems.append(f"{t}: {mset ^ gset}")
        for c, tgt, od, name in mig[t]["fks"]:
            ref_table, ref_col = tgt.split(".")
            expected = f"fk_{t}_{c}_{ref_table}"
            if name != expected:
                fk_problems.append(f"{t}.{c}: FK name {name} != {expected}")
            if ref_table not in mig or ref_col not in mig[ref_table]["cols"]:
                fk_problems.append(f"{t}.{c}: references missing {tgt}")
                continue
            if mig[t]["cols"][c]["type"] != mig[ref_table]["cols"][ref_col]["type"]:
                fk_problems.append(f"{t}.{c}: type {mig[t]['cols'][c]['type']} != referenced {tgt} {mig[ref_table]['cols'][ref_col]['type']}")
            if od != "RESTRICT":
                fk_problems.append(f"{t}.{c}: ondelete={od} (must be RESTRICT)")
            if list(mig).index(ref_table) > list(mig).index(t):
                fk_problems.append(f"{t}.{c}: parent {ref_table} created AFTER child")
    check(not fk_problems, f"{fk_count} foreign keys: match models, reference real columns of the same type, all RESTRICT, parents created first" + (f" -> {fk_problems[:6]}" if fk_problems else ""))

    # ---- check constraints / unique / indexes
    for label, key in (("CHECK constraints", "checks"), ("unique constraints", "uniques"), ("indexes", "indexes")):
        problems = []
        total = 0
        for t in sorted(set(model) & set(mig)):
            m, g = model[t][key], mig[t][key]
            total += len(g)
            for n in set(m) | set(g):
                if n not in m:
                    problems.append(f"{t}: {n} only in migration")
                elif n not in g:
                    problems.append(f"{t}: {n} only in models")
                elif m[n] != g[n]:
                    problems.append(f"{t}: {n} differs: {m[n]} vs {g[n]}")
        check(not problems, f"{total} {label} identical in models and migration" + (f" -> {problems[:5]}" if problems else ""))

    # ---- required capabilities by name
    required_unique = {
        "vehicles": "uq_vehicles_reg_no",
        "uploaded_files": "uq_uploaded_files_sha256",
        "reports": "uq_reports_year_month_version",
        "daily_km": "uq_daily_km_report_vehicle_id_reading_date",
        "daily_status": "uq_daily_status_report_vehicle_id_status_date",
        "report_vehicles": "uq_report_vehicles_report_id_vehicle_id",
        "status_definitions": "uq_status_definitions_code",
        "status_aliases": "uq_status_aliases_alias_normalized",
        "monthly_financials": "uq_monthly_financials_report_vehicle_id",
        "data_corrections": "uq_data_corrections_reverses_correction_id",
        "users": "uq_users_email",
    }
    check(all(n in mig[t]["uniques"] for t, n in required_unique.items()), "required uniqueness rules exist (registration, file hash, report version, vehicle+date, aliases, one reversal per correction ...)")
    check("uq_reports_current_year_month" in mig["reports"]["indexes"] and mig["reports"]["indexes"]["uq_reports_current_year_month"][2] == "is_current", "only one current report per year+month (partial unique index)")
    check(all(mig[t]["cols"][c]["nullable"] for t, cs in {"monthly_financials": ["revenue", "erp_km", "trips", "cars_lifted"], "daily_km": ["km"]}.items() for c in cs) and all(mig["monthly_financials"]["cols"][c]["default"] is None for c in ["revenue", "erp_km", "trips", "cars_lifted"]), "financial values and km are nullable with NO default (unavailable stays NULL, never 0)")
    ts_ok = all(v["type"] == "DateTime(tz=True)" for t in mig for c, v in mig[t]["cols"].items() if c in {"created_at", "updated_at", "occurred_at", "corrected_at", "uploaded_at", "calculated_at"})
    check(ts_ok, "all audit/creation/update timestamps are timezone-aware (UTC) timestamptz")
    check(mig["daily_km"]["cols"]["km"]["type"] == "Numeric(10,2)" and mig["monthly_financials"]["cols"]["revenue"]["type"] == "Numeric(14,2)", "km and money use NUMERIC, not floats")

    # ---- CHECK truth tables
    km_expr = mig["daily_km"]["checks"]["ck_daily_km_km_matches_state"]
    ok = True
    for state in ("actual", "reported_zero", "gps_offline", "missing", "invalid"):
        for km in (None, Decimal("0"), Decimal("0.5"), Decimal("57.5"), Decimal("-1")):
            expected = (
                (state == "actual" and km is not None and km > 0)
                or (state == "reported_zero" and km is not None and km == 0)
                or (state in ("gps_offline", "missing", "invalid") and km is None)
            )
            if evaluate(km_expr, data_state=state, km=km) != expected:
                ok = False
                print("      mismatch:", state, km)
    check(ok, "daily_km rule: Offline/Missing/Invalid only with NULL km, zero only as 'reported_zero', 'actual' needs km > 0 (25 combinations)")
    check(not evaluate(km_expr, data_state="gps_offline", km=Decimal("0")) and not evaluate(km_expr, data_state="missing", km=Decimal("0")), "Offline and Missing can never be stored as 0 km")

    ds_expr = mig["daily_status"]["checks"]["ck_daily_status_definition_matches_state"]
    cases = [
        ("recognized", 1, "Running", True), ("recognized", None, "Running", False), ("recognized", 1, None, False),
        ("unrecognized", None, "Random text", True), ("unrecognized", 1, "Random text", False), ("unrecognized", None, None, False),
        ("unrecognized", None, "   ", False), ("missing", None, None, True), ("missing", 1, None, False), ("missing", None, "x", False),
    ]
    ok = all(evaluate(ds_expr, match_state=m, status_definition_id=d, matched_alias_id=None, source_text=s) == exp for m, d, s, exp in cases)
    check(ok, "daily_status rule: recognized needs a definition; unrecognized and missing never carry one (10 cases)")

    rep = mig["reports"]["checks"]
    ok = (
        evaluate(rep["ck_reports_current_must_be_active"], is_current=True, status="active")
        and not evaluate(rep["ck_reports_current_must_be_active"], is_current=True, status="superseded")
        and evaluate(rep["ck_reports_superseded_consistency"], status="superseded", superseded_at=1)
        and not evaluate(rep["ck_reports_superseded_consistency"], status="superseded", superseded_at=None)
        and not evaluate(rep["ck_reports_superseded_consistency"], status="active", superseded_at=1)
    )
    check(ok, "report rules: current must be active; superseded status and superseded_at agree")
    dc = mig["data_corrections"]["checks"]
    ok = (
        evaluate(dc["ck_data_corrections_reversal_links_original"], correction_type="reversal", reverses_correction_id=5)
        and evaluate(dc["ck_data_corrections_reversal_links_original"], correction_type="correction", reverses_correction_id=None)
        and not evaluate(dc["ck_data_corrections_reversal_links_original"], correction_type="correction", reverses_correction_id=5)
        and not evaluate(dc["ck_data_corrections_reversal_links_original"], correction_type="reversal", reverses_correction_id=None)
        and not evaluate(dc["ck_data_corrections_reason_not_blank"], reason="   ")
    )
    check(ok, "correction rules: reversal rows must reference the corrected row; blank reasons rejected")

    # ---- enum values vs CHECK text
    from app.models import enums as E

    pairs = [
        ("users", "role", E.UserRole), ("uploaded_files", "status", E.UploadStatus),
        ("reports", "status", E.ReportStatus), ("import_issues", "severity", E.IssueSeverity),
        ("daily_km", "data_state", E.KmDataState), ("daily_status", "match_state", E.StatusMatchState),
        ("status_definitions", "category", E.StatusCategory), ("data_corrections", "correction_type", E.CorrectionType),
        ("data_corrections", "target_table", E.CorrectionTarget), ("ai_messages", "role", E.MessageRole),
        ("ai_messages", "channel", E.MessageChannel), ("ai_reports", "kind", E.AiReportKind),
    ]
    bad = []
    for t, c, enum in pairs:
        text_ = mig[t]["checks"][f"ck_{t}_{c}"]
        found = set(re.findall(r"'([^']+)'", text_))
        if found != {m.value for m in enum}:
            bad.append(f"{t}.{c}")
    check(not bad, f"{len(pairs)} enum classes match their CHECK constraints exactly" + (f" -> {bad}" if bad else ""))

    # ---- seed
    from app.database.seed import DEFAULT_STATUS_DEFINITIONS

    seed = [(c, n, cat) for c, n, cat, _, _ in module.STATUS_SEED]
    check(seed == list(DEFAULT_STATUS_DEFINITIONS), "migration seed equals app/database/seed.py")
    cats = [cat for _, _, cat in seed]
    names = {n for _, n, _ in seed}
    check(
        cats.count("utilized") == 5 and cats.count("unutilized") == 5 and cats.count("unclassified") == 1
        and dict((n, cat) for _, n, cat in seed)["Driver Home"] == "unclassified",
        "seed: 5 utilized, 5 unutilized, Driver Home unclassified",
    )
    check(
        names == {"Running", "Empty Running", "Unloading", "Load Allotted", "Waiting for Dispatch",
                  "Waiting for Load", "Under Maintenance", "Accident", "Halting", "No Driver Assigned", "Driver Home"}
        and not any("sold" in n.lower() for n in names),
        "seed contains exactly the 11 approved statuses ('To be Sold' is not one of them)",
    )
    rows = bulk[0][1] if bulk else []
    check(len(bulk) == 1 and len(rows) == 11 and len({r["code"] for r in rows}) == 11, "seed inserted exactly once, 11 unique rows")
    check(sum("INSERT INTO status_aliases" in s for s in executed) == 1, "aliases seeded once (one per definition)")

    # ---- append-only protection and downgrade
    trig = [s for s in executed if s.startswith("CREATE TRIGGER")]
    expected_triggers = len(module.APPEND_ONLY_TABLES) + len(module.NO_DELETE_TABLES)
    check(len(trig) == expected_triggers and set(module.APPEND_ONLY_TABLES) <= set(mig) and set(module.NO_DELETE_TABLES) <= set(mig), f"{expected_triggers} protection triggers on existing tables")
    check({"audit_log", "data_corrections", "daily_km", "daily_status", "import_raw_rows"} <= set(module.APPEND_ONLY_TABLES), "audit, corrections and original imported data are append-only")
    check(dropped == list(reversed(list(mig))) and set(dropped) == set(mig), "downgrade drops every created table, children before parents")
    check(any("DROP FUNCTION" in s and "fleetiq_block_delete" in s for s in down_exec) and any("DROP FUNCTION" in s and "fleetiq_block_update_delete" in s for s in down_exec), "downgrade also drops the two trigger functions")

    # ---- migration chain
    check(module.revision == "0002" and module.down_revision == "0001", "migration chain: 0001 -> 0002")
    base = BASELINE.read_text()
    check('revision: str = "0001"' in base and "def upgrade() -> None:\n    pass" in base, "baseline migration 0001 untouched (still empty)")

    failed = [m for ok_, m in results if not ok_]
    print(f"\n{len(results) - len(failed)} passed, {len(failed)} failed")
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
