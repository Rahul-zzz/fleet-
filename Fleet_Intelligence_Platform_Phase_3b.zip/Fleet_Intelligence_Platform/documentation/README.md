# Documentation

Project documentation is kept here and updated each phase.

- Phase 1: workbook analysis (data structure, data-quality findings)
- Phase 2: architecture (system, database, API, ingestion, Copilot, voice, security, deployment)
- Phase 3a: project skeleton. See the root `README.md` for setup and run instructions.
- Phase 3b: database schema. See [`database-schema.md`](database-schema.md) (ER diagrams, table purposes,
  enforced rules, seed data).
