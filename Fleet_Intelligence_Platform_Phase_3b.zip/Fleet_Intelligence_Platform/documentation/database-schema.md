# FLEETIQ database schema (Phase 3b)

PostgreSQL 16, SQLAlchemy 2.x models in `backend/app/models/`, created by Alembic migration
`0002` (`database/migrations/versions/20261123_0002_phase3b_schema.py`).
22 tables. This phase defines structure only: no Excel parsing, metrics, authentication,
dashboards or AI logic.

The diagrams below were generated from the same definitions that
`scripts/static_schema_check.py` verifies against the migration. They are Mermaid; view them
in VS Code (Markdown Preview Mermaid Support extension), GitHub, or https://mermaid.live.
(The diagrams could not be rendered in the environment that produced this project, so if one
fails to render, tell me.)

## 1. Overview: how the tables relate

```mermaid
erDiagram
    users |o--o{ import_profiles : "created_by_user_id"
    status_definitions ||--o{ status_aliases : "status_definition_id"
    users |o--o{ status_aliases : "created_by_user_id"
    status_definitions ||--o{ status_definition_history : "status_definition_id"
    users |o--o{ status_definition_history : "changed_by_user_id"
    import_profiles |o--o{ uploaded_files : "import_profile_id"
    users ||--o{ uploaded_files : "uploaded_by_user_id"
    uploaded_files ||--o{ reports : "source_file_id"
    import_profiles |o--o{ reports : "import_profile_id"
    reports |o--o{ reports : "supersedes_report_id"
    users |o--o{ reports : "confirmed_by_user_id"
    uploaded_files ||--o{ import_raw_rows : "uploaded_file_id"
    uploaded_files ||--o{ import_issues : "uploaded_file_id"
    reports |o--o{ import_issues : "report_id"
    reports ||--o{ report_vehicles : "report_id"
    vehicles ||--o{ report_vehicles : "vehicle_id"
    report_vehicles ||--o{ daily_km : "report_vehicle_id"
    report_vehicles ||--o{ daily_status : "report_vehicle_id"
    status_definitions |o--o{ daily_status : "status_definition_id"
    status_aliases |o--o{ daily_status : "matched_alias_id"
    report_vehicles ||--o{ monthly_financials : "report_vehicle_id"
    reports |o--o{ data_corrections : "report_id"
    report_vehicles |o--o{ data_corrections : "report_vehicle_id"
    users ||--o{ data_corrections : "corrected_by_user_id"
    data_corrections |o--o{ data_corrections : "reverses_correction_id"
    data_corrections |o--o{ data_corrections : "supersedes_correction_id"
    report_vehicles ||--o{ vehicle_metrics : "report_vehicle_id"
    reports ||--o{ report_metrics : "report_id"
    users ||--o{ ai_conversations : "user_id"
    ai_conversations ||--o{ ai_messages : "conversation_id"
    reports ||--o{ ai_reports : "report_id"
    ai_conversations |o--o{ ai_reports : "conversation_id"
    users |o--o{ ai_reports : "generated_by_user_id"
    users |o--o{ settings : "updated_by_user_id"
    users |o--o{ audit_log : "actor_user_id"
```

## 2. Tables and their purpose

| Group | Table | Purpose |
|---|---|---|
| Security | `users` | Accounts: email, **password hash only**, role (`admin` / `analyst`), active flag, lockout fields. Never deleted, only deactivated. |
| Security | `audit_log` | Append-only trail: who, what, which entity, when, before/after JSON, IP. |
| Files and reports | `uploaded_files` | One row per uploaded `.xlsx` / `.xlsm`: filename, SHA-256 (unique), size, storage reference, upload user/time, macro-detected flag (macros are never executed), admin-declared year/month. |
| Files and reports | `import_profiles` | Versioned JSONB mapping configuration (worksheets and columns) for future imports. |
| Files and reports | `reports` | One **version** of one monthly report: explicit year and month, version, status, `is_current`, link to the report it supersedes. Only one current report per month. |
| Files and reports | `import_raw_rows` | Every source worksheet row as imported (JSONB), append-only. |
| Files and reports | `import_issues` | Validation warnings and errors (severity, code, sheet/row/column, raw value). |
| Vehicles | `vehicles` | Vehicle identity. Canonical registration number is unique and is the only matching key. Holds the latest route/type. |
| Vehicles | `report_vehicles` | A vehicle's snapshot inside one report (route, type, remarks, source row), so history never changes silently. |
| Daily data | `daily_km` | One vehicle-day of GPS km with a **data state**: `actual`, `reported_zero`, `gps_offline`, `missing`, `invalid`. Original text and source position kept. Append-only. |
| Daily data | `daily_status` | One vehicle-day of status: original text, match state (`recognized` / `unrecognized` / `missing`), canonical definition when recognized. Append-only. |
| Source data | `monthly_financials` | Revenue, ERP km, trips, cars per vehicle per report. Unavailable = NULL, never 0. |
| Status config | `status_definitions` | The 11 approved statuses and their category (`utilized` / `unutilized` / `unclassified`). Seeded by the migration; classification is editable, definitions are never deleted. |
| Status config | `status_aliases` | Spellings (normalized) that map to a definition. One seeded per definition. |
| Status config | `status_definition_history` | Append-only record of every classification change (extra table, added so edits never destroy history). |
| Corrections | `data_corrections` | Append-only corrections: target, field, original value, corrected value, reason, user, time, and links for reversal / superseding. |
| Metrics | `vehicle_metrics` | Cache of derived per-vehicle metrics (JSONB), calculation version/time, provenance, current/invalidated flags. Structure only. |
| Metrics | `report_metrics` | Same for fleet-level metrics per report. Structure only. |
| AI | `ai_conversations` | Copilot conversations (text and voice share one). Structure only. |
| AI | `ai_messages` | Messages with role, channel (`text` / `voice`), tool calls, provider/model. Structure only. |
| AI | `ai_reports` | Generated narratives with the figures they cite. Structure only. |
| Config | `settings` | Key/value configuration (JSONB). No values are seeded in this phase. |

## 3. Rules the database enforces

| Rule | How |
|---|---|
| Offline and Missing are never zero | `daily_km.km` is NULL for `gps_offline`, `missing`, `invalid`; `0` is only valid as `reported_zero`; `actual` requires km > 0 (CHECK `km_matches_state`). |
| Unavailable financial values are never zero | Columns are nullable with no default; `monthly_financials` has no derived metrics. |
| One reading per vehicle per day | Unique `(report_vehicle_id, reading_date)` and `(report_vehicle_id, status_date)`. Any real calendar date is storable (day 31, 29 February). |
| Vehicles matched by registration only | `vehicles.reg_no` unique, canonical (`^[A-Z0-9]{4,20}$`). No table uses row order or S.No as a key. |
| Reporting year/month are explicit | `reports.year` / `reports.month` (and `uploaded_files.declared_*`) are plain columns confirmed by an administrator; nothing is inferred. |
| Report versions and replacement | Unique `(year, month, version)`; partial unique index allows **one current** report per month; a current report must be `active`; a replacement is a new row with `supersedes_report_id` and the old row becomes `superseded`. |
| No duplicate imports | `uploaded_files.sha256` is unique. |
| Unknown statuses are not classified | `daily_status.match_state = 'unrecognized'` rows carry no definition; the CHECK forbids it. |
| Corrections are append-only | Trigger rejects UPDATE/DELETE on `data_corrections`; a reversal is a new row (`correction_type = 'reversal'`) that references the original; each correction can be reversed once (unique). |
| Original imported data is immutable | Triggers reject UPDATE/DELETE on `daily_km`, `daily_status`, `import_raw_rows`. Fixes are corrections, replacements are new report versions. |
| Audit and status history are append-only | Triggers on `audit_log` and `status_definition_history`. |
| History cannot be deleted | Every foreign key is `ON DELETE RESTRICT` (no cascades). Extra DELETE-blocking triggers protect users, uploaded files, reports, vehicles, report vehicles, status definitions/aliases, import profiles and financials. `TRUNCATE` is not blocked; it is a maintenance action. |
| No plaintext passwords | `users.password_hash` must look like a modular-crypt hash (`$argon2id$...`, `$2b$...`). |
| UTC timestamps | All timestamps are `timestamptz`; connections are opened with `timezone=utc`. |

## 4. Detailed diagram (all columns)

PK = primary key, FK = foreign key, UK = single-column unique. Composite unique constraints
and CHECK constraints are listed in the migration.

```mermaid
erDiagram
    users {
        uuid id PK
        varchar email UK
        varchar full_name
        varchar password_hash
        varchar role
        bool is_active
        int failed_login_count
        timestamptz locked_until
        timestamptz last_login_at
        timestamptz password_changed_at
        timestamptz created_at
        timestamptz updated_at
    }
    import_profiles {
        uuid id PK
        varchar name
        int version
        text description
        jsonb config
        bool is_active
        uuid created_by_user_id FK
        timestamptz created_at
        timestamptz updated_at
    }
    status_definitions {
        int id PK
        varchar code UK
        varchar display_name UK
        varchar category
        smallint sort_order
        bool is_active
        bool is_system
        text description
        timestamptz created_at
        timestamptz updated_at
    }
    status_aliases {
        int id PK
        int status_definition_id FK
        varchar alias_normalized UK
        varchar alias_display
        bool is_active
        uuid created_by_user_id FK
        timestamptz created_at
        timestamptz updated_at
    }
    status_definition_history {
        bigint id PK
        int status_definition_id FK
        varchar field_name
        varchar old_value
        varchar new_value
        uuid changed_by_user_id FK
        text reason
        timestamptz created_at
    }
    uploaded_files {
        uuid id PK
        varchar original_filename
        varchar file_extension
        varchar content_type
        bigint size_bytes
        varchar sha256 UK
        varchar storage_ref
        varchar status
        bool contains_macros
        uuid import_profile_id FK
        smallint declared_year
        smallint declared_month
        jsonb file_metadata
        uuid uploaded_by_user_id FK
        timestamptz uploaded_at
        timestamptz created_at
        timestamptz updated_at
    }
    reports {
        uuid id PK
        smallint year
        smallint month
        int version
        varchar status
        bool is_current
        smallint days_in_month
        uuid source_file_id FK
        uuid import_profile_id FK
        uuid supersedes_report_id FK
        timestamptz superseded_at
        text replacement_reason
        uuid confirmed_by_user_id FK
        timestamptz confirmed_at
        text notes
        timestamptz created_at
        timestamptz updated_at
    }
    import_raw_rows {
        bigint id PK
        uuid uploaded_file_id FK
        varchar sheet_name
        int row_number
        jsonb payload
        timestamptz created_at
    }
    import_issues {
        bigint id PK
        uuid uploaded_file_id FK
        uuid report_id FK
        varchar severity
        varchar code
        text message
        varchar sheet_name
        int row_number
        varchar column_ref
        text raw_value
        jsonb details
        timestamptz created_at
    }
    vehicles {
        uuid id PK
        varchar reg_no UK
        varchar route
        varchar vehicle_type
        bool is_active
        text notes
        timestamptz created_at
        timestamptz updated_at
    }
    report_vehicles {
        uuid id PK
        uuid report_id FK
        uuid vehicle_id FK
        varchar reg_no_as_imported
        varchar route
        varchar vehicle_type
        varchar source_sheet
        int source_row
        text remarks
        jsonb attributes
        timestamptz created_at
    }
    daily_km {
        bigint id PK
        uuid report_vehicle_id FK
        date reading_date
        text source_text
        numeric km
        varchar data_state
        varchar source_sheet
        int source_row
        varchar source_column
        timestamptz created_at
    }
    daily_status {
        bigint id PK
        uuid report_vehicle_id FK
        date status_date
        text source_text
        varchar match_state
        int status_definition_id FK
        int matched_alias_id FK
        varchar source_sheet
        int source_row
        varchar source_column
        timestamptz created_at
    }
    monthly_financials {
        bigint id PK
        uuid report_vehicle_id FK,UK
        numeric revenue
        numeric erp_km
        int trips
        int cars_lifted
        varchar source_sheet
        jsonb source_values
        timestamptz created_at
    }
    data_corrections {
        bigint id PK
        uuid report_id FK
        uuid report_vehicle_id FK
        varchar target_table
        varchar target_id
        varchar field_name
        jsonb original_value
        jsonb corrected_value
        text reason
        varchar correction_type
        uuid corrected_by_user_id FK
        timestamptz corrected_at
        bigint reverses_correction_id FK,UK
        bigint supersedes_correction_id FK
    }
    vehicle_metrics {
        bigint id PK
        uuid report_vehicle_id FK
        varchar calc_version
        jsonb metric_values
        jsonb provenance
        varchar inputs_fingerprint
        timestamptz calculated_at
        bool is_current
        timestamptz invalidated_at
        text invalidation_reason
        timestamptz created_at
        timestamptz updated_at
    }
    report_metrics {
        bigint id PK
        uuid report_id FK
        varchar calc_version
        jsonb metric_values
        jsonb provenance
        varchar inputs_fingerprint
        timestamptz calculated_at
        bool is_current
        timestamptz invalidated_at
        text invalidation_reason
        timestamptz created_at
        timestamptz updated_at
    }
    ai_conversations {
        uuid id PK
        uuid user_id FK
        varchar title
        jsonb context_state
        timestamptz archived_at
        timestamptz created_at
        timestamptz updated_at
    }
    ai_messages {
        bigint id PK
        uuid conversation_id FK
        int sequence
        varchar role
        varchar channel
        text content
        jsonb tool_calls
        varchar provider
        varchar model
        jsonb token_usage
        timestamptz created_at
    }
    ai_reports {
        uuid id PK
        uuid report_id FK
        varchar kind
        text narrative
        jsonb source_figures
        varchar calc_version
        uuid conversation_id FK
        uuid generated_by_user_id FK
        varchar provider
        varchar model
        timestamptz created_at
    }
    settings {
        varchar setting_key PK
        jsonb value
        text description
        uuid updated_by_user_id FK
        timestamptz created_at
        timestamptz updated_at
    }
    audit_log {
        bigint id PK
        timestamptz occurred_at
        uuid actor_user_id FK
        varchar actor_email
        varchar action
        varchar entity_type
        varchar entity_id
        jsonb before_data
        jsonb after_data
        jsonb details
        inet ip_address
        varchar request_id
    }
    users |o--o{ import_profiles : "created_by_user_id"
    status_definitions ||--o{ status_aliases : "status_definition_id"
    users |o--o{ status_aliases : "created_by_user_id"
    status_definitions ||--o{ status_definition_history : "status_definition_id"
    users |o--o{ status_definition_history : "changed_by_user_id"
    import_profiles |o--o{ uploaded_files : "import_profile_id"
    users ||--o{ uploaded_files : "uploaded_by_user_id"
    uploaded_files ||--o{ reports : "source_file_id"
    import_profiles |o--o{ reports : "import_profile_id"
    reports |o--o{ reports : "supersedes_report_id"
    users |o--o{ reports : "confirmed_by_user_id"
    uploaded_files ||--o{ import_raw_rows : "uploaded_file_id"
    uploaded_files ||--o{ import_issues : "uploaded_file_id"
    reports |o--o{ import_issues : "report_id"
    reports ||--o{ report_vehicles : "report_id"
    vehicles ||--o{ report_vehicles : "vehicle_id"
    report_vehicles ||--o{ daily_km : "report_vehicle_id"
    report_vehicles ||--o{ daily_status : "report_vehicle_id"
    status_definitions |o--o{ daily_status : "status_definition_id"
    status_aliases |o--o{ daily_status : "matched_alias_id"
    report_vehicles ||--o{ monthly_financials : "report_vehicle_id"
    reports |o--o{ data_corrections : "report_id"
    report_vehicles |o--o{ data_corrections : "report_vehicle_id"
    users ||--o{ data_corrections : "corrected_by_user_id"
    data_corrections |o--o{ data_corrections : "reverses_correction_id"
    data_corrections |o--o{ data_corrections : "supersedes_correction_id"
    report_vehicles ||--o{ vehicle_metrics : "report_vehicle_id"
    reports ||--o{ report_metrics : "report_id"
    users ||--o{ ai_conversations : "user_id"
    ai_conversations ||--o{ ai_messages : "conversation_id"
    reports ||--o{ ai_reports : "report_id"
    ai_conversations |o--o{ ai_reports : "conversation_id"
    users |o--o{ ai_reports : "generated_by_user_id"
    users |o--o{ settings : "updated_by_user_id"
    users |o--o{ audit_log : "actor_user_id"
```

## 5. Seed data (migration 0002)

| Category | Statuses |
|---|---|
| utilized | Running, Empty Running, Unloading, Load Allotted, Waiting for Dispatch |
| unutilized | Waiting for Load, Under Maintenance, Accident, Halting, No Driver Assigned |
| unclassified | Driver Home (until the company confirms its classification) |

"To be Sold" is **not** seeded. If it appears in a workbook it is stored as `unrecognized`
until an administrator decides how to handle it.
