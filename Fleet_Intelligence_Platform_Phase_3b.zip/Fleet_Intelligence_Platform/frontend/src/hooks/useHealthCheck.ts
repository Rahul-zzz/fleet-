import { useCallback, useEffect, useState } from 'react'
import { getApiHealth, getDatabaseHealth } from '../services/health'
import type { DatabaseHealthResponse, HealthResponse } from '../types/health'

export type CheckState<T> =
  | { status: 'loading' }
  | { status: 'ok'; data: T }
  | { status: 'error'; message: string }

const toMessage = (error: unknown): string =>
  error instanceof Error ? error.message : 'Unknown error'

export function useHealthCheck() {
  const [api, setApi] = useState<CheckState<HealthResponse>>({ status: 'loading' })
  const [db, setDb] = useState<CheckState<DatabaseHealthResponse>>({ status: 'loading' })
  const [attempt, setAttempt] = useState(0)

  useEffect(() => {
    const controller = new AbortController()

    getApiHealth(controller.signal)
      .then((data) => setApi({ status: 'ok', data }))
      .catch((error) => {
        if (!controller.signal.aborted) setApi({ status: 'error', message: toMessage(error) })
      })

    getDatabaseHealth(controller.signal)
      .then((data) => setDb({ status: 'ok', data }))
      .catch((error) => {
        if (!controller.signal.aborted) setDb({ status: 'error', message: toMessage(error) })
      })

    return () => controller.abort()
  }, [attempt])

  const recheck = useCallback(() => {
    setApi({ status: 'loading' })
    setDb({ status: 'loading' })
    setAttempt((n) => n + 1)
  }, [])

  return { api, db, recheck }
}
