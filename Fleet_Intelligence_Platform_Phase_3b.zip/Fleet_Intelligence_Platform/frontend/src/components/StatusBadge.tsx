type Props = { status: 'loading' | 'ok' | 'error' }

const STYLES: Record<Props['status'], string> = {
  loading: 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-300',
  ok: 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-300',
  error: 'bg-red-100 text-red-800 dark:bg-red-900/40 dark:text-red-300',
}

const LABELS: Record<Props['status'], string> = {
  loading: 'Checking…',
  ok: 'Connected',
  error: 'Failed',
}

export default function StatusBadge({ status }: Props) {
  return (
    <span className={`rounded-full px-3 py-1 text-xs font-semibold ${STYLES[status]}`}>
      {LABELS[status]}
    </span>
  )
}
