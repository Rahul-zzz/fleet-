import { apiGet } from './api'
import type { DatabaseHealthResponse, HealthResponse } from '../types/health'

export const getApiHealth = (signal?: AbortSignal) =>
  apiGet<HealthResponse>('/health', signal)

export const getDatabaseHealth = (signal?: AbortSignal) =>
  apiGet<DatabaseHealthResponse>('/health/db', signal)
