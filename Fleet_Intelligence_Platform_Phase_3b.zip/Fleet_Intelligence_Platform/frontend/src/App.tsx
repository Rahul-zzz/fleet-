import ConnectivityTest from './pages/ConnectivityTest'

export default function App() {
  return <ConnectivityTest />
}
