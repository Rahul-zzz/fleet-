export type HealthResponse = {
  status: string
  service: string
  environment: string
  version: string
  timestamp: string
}

export type DatabaseHealthResponse = {
  status: string
  database: string
}
