import StatusBadge from '../components/StatusBadge'
import { useHealthCheck } from '../hooks/useHealthCheck'
import type { CheckState } from '../hooks/useHealthCheck'

type CardProps = {
  title: string
  description: string
  state: CheckState<Record<string, string>>
}

function CheckCard({ title, description, state }: CardProps) {
  return (
    <section className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-700 dark:bg-slate-900">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h2 className="text-base font-semibold">{title}</h2>
          <p className="text-sm text-slate-500 dark:text-slate-400">{description}</p>
        </div>
        <StatusBadge status={state.status} />
      </div>

      {state.status === 'ok' && (
        <dl className="mt-4 grid grid-cols-[auto_1fr] gap-x-4 gap-y-1 text-sm">
          {Object.entries(state.data).map(([key, value]) => (
            <div key={key} className="contents">
              <dt className="text-slate-500 dark:text-slate-400">{key}</dt>
              <dd className="font-mono">{value}</dd>
            </div>
          ))}
        </dl>
      )}

      {state.status === 'error' && (
        <p className="mt-4 text-sm text-red-700 dark:text-red-300">{state.message}</p>
      )}
    </section>
  )
}

export default function ConnectivityTest() {
  const { api, db, recheck } = useHealthCheck()

  return (
    <main className="min-h-screen bg-slate-50 text-slate-900 dark:bg-slate-950 dark:text-slate-100">
      <div className="mx-auto max-w-2xl space-y-6 px-6 py-12">
        <header>
          <h1 className="text-2xl font-bold tracking-tight">FLEETIQ</h1>
          <p className="text-sm text-slate-500 dark:text-slate-400">
            Phase 3a · connectivity test
          </p>
        </header>

        <CheckCard
          title="Backend API"
          description="Frontend → FastAPI (/api/v1/health)"
          state={api}
        />
        <CheckCard
          title="Database"
          description="FastAPI → PostgreSQL (/api/v1/health/db)"
          state={db}
        />

        <button
          onClick={recheck}
          className="rounded-lg bg-slate-900 px-4 py-2 text-sm font-medium text-white hover:bg-slate-700 dark:bg-slate-100 dark:text-slate-900 dark:hover:bg-slate-300"
        >
          Re-run checks
        </button>
      </div>
    </main>
  )
}
