import pytest

from app.utils.registration import (
    InvalidRegistrationError,
    normalize_registration,
    try_normalize_registration,
)


@pytest.mark.parametrize(
    ("raw", "expected"),
    [
        ("GJ08AU1533", "GJ08AU1533"),
        ("  gj08au1533 ", "GJ08AU1533"),
        ("GJ-08-AU-1533", "GJ08AU1533"),
        ("nl 01 q 5688", "NL01Q5688"),
        ("NL01Q5688\n", "NL01Q5688"),
        ("CH6862", "CH6862"),
    ],
)
def test_normalizes_to_canonical_form(raw, expected):
    assert normalize_registration(raw) == expected


def test_same_vehicle_in_different_spellings_gets_one_key():
    assert normalize_registration("hr 55 ab 1234") == normalize_registration("HR55AB1234")


def test_letters_are_never_substituted():
    # O and 0 are different characters and must stay different.
    assert normalize_registration("NL01O5688") != normalize_registration("NL0105688")


@pytest.mark.parametrize("bad", [None, "", "   ", "---", "AB1", "X" * 21])
def test_invalid_values_raise(bad):
    with pytest.raises(InvalidRegistrationError):
        normalize_registration(bad)
    assert try_normalize_registration(bad) is None
