from datetime import date

import pytest

from app.utils.calendar_utils import dates_in_month, days_in_month, validate_period


@pytest.mark.parametrize(
    ("year", "month", "days"),
    [(2026, 10, 31), (2026, 11, 30), (2026, 2, 28), (2028, 2, 29), (2100, 2, 28), (2026, 12, 31)],
)
def test_days_in_month_includes_day_31_and_leap_february(year, month, days):
    assert days_in_month(year, month) == days


def test_october_2026_has_all_31_dates():
    dates = dates_in_month(2026, 10)
    assert len(dates) == 31
    assert dates[0] == date(2026, 10, 1)
    assert dates[-1] == date(2026, 10, 31)


def test_leap_february_has_29th():
    assert date(2028, 2, 29) in dates_in_month(2028, 2)


@pytest.mark.parametrize(("year", "month"), [(2026, 0), (2026, 13), (1999, 5), (2101, 5)])
def test_invalid_period_rejected(year, month):
    with pytest.raises(ValueError):
        validate_period(year, month)
