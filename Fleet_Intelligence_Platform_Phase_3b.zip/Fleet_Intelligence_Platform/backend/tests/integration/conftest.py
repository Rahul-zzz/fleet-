"""Integration tests run against the REAL PostgreSQL container.

Prerequisites: `docker compose up -d` and `alembic upgrade head` (from the backend folder),
and a backend/.env that matches the root .env. Each test runs inside a transaction that is
rolled back, so the database is left unchanged.
"""
import pytest
from sqlalchemy.orm import Session

from app.database.session import engine


@pytest.fixture
def db():
    connection = engine.connect()
    outer = connection.begin()
    session = Session(bind=connection, join_transaction_mode="create_savepoint")
    try:
        yield session
    finally:
        session.close()
        outer.rollback()
        connection.close()
