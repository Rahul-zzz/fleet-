from datetime import date
from decimal import Decimal

import pytest
from sqlalchemy import func, select, text
from sqlalchemy.exc import DBAPIError

from app.models import (
    DailyKm, DailyStatus, MonthlyFinancial, StatusAlias, StatusDefinition, User, Vehicle,
)
from app.repositories.audit import AuditRepository
from app.repositories.corrections import CorrectionError, CorrectionRepository
from app.repositories.status import StatusRepository
from app.repositories.vehicles import VehicleRepository
from tests.integration.factories import (
    FAKE_HASH, make_report, make_report_vehicle, make_user, make_vehicle,
)

pytestmark = pytest.mark.integration


def rejected(db, *objects):
    """True if the database refuses these rows (inside a savepoint)."""
    try:
        with db.begin_nested():
            db.add_all(objects)
            db.flush()
    except DBAPIError:
        return True
    return False


# ------------------------------------------------------------------ migration + seed
def test_migration_applied_and_seed_present(db):
    assert db.scalar(text("SELECT version_num FROM alembic_version")) is not None  # run `alembic upgrade head`
    rows = db.execute(select(StatusDefinition.display_name, StatusDefinition.category)).all()
    assert len(rows) == 11
    by_category = {}
    for name, category in rows:
        by_category.setdefault(category, set()).add(name)
    assert by_category["utilized"] == {"Running", "Empty Running", "Unloading", "Load Allotted", "Waiting for Dispatch"}
    assert by_category["unutilized"] == {"Waiting for Load", "Under Maintenance", "Accident", "Halting", "No Driver Assigned"}
    assert by_category["unclassified"] == {"Driver Home"}
    assert db.scalar(select(func.count()).select_from(StatusAlias)) == 11


def test_status_resolution_never_classifies_unknown_text(db):
    repo = StatusRepository(db)
    assert repo.resolve("  waiting for   LOAD ").definition.code == "waiting_for_load"
    assert repo.resolve("To be Sold").match_state == "unrecognized"
    assert repo.resolve("To be Sold").definition is None
    assert repo.resolve(None).match_state == "missing"
    assert repo.resolve("Driver Home").definition.category == "unclassified"


def test_changing_a_classification_appends_history(db):
    user = make_user(db)
    repo = StatusRepository(db)
    definition = repo.get_by_code("driver_home")
    history = repo.set_category(definition, "unutilized", user.id, "test")
    assert history.old_value == "unclassified" and history.new_value == "unutilized"
    assert len(definition.history) == 1


# ------------------------------------------------------------------ users
def test_plaintext_password_is_rejected_by_the_database(db):
    assert rejected(db, User(email="a1@example.test", full_name="A", password_hash="plain-text-password-1234567890123456789012345"))
    assert not rejected(db, User(email="a2@example.test", full_name="A", password_hash=FAKE_HASH))


def test_email_must_be_lowercase_and_unique(db):
    assert rejected(db, User(email="Upper@Example.test", full_name="A", password_hash=FAKE_HASH))
    make_user(db)
    user = make_user(db)
    assert rejected(db, User(email=user.email, full_name="Dup", password_hash=FAKE_HASH))


# ------------------------------------------------------------------ vehicles
def test_registration_is_canonical_and_unique(db):
    repo = VehicleRepository(db)
    first, created = repo.get_or_create(" tst-12-ab-3456 ")
    assert created and first.reg_no == "TST12AB3456"
    second, created_again = repo.get_or_create("TST12AB3456")
    assert not created_again and second.id == first.id
    assert rejected(db, Vehicle(reg_no="lower123"))
    assert rejected(db, Vehicle(reg_no="TST12AB3456"))


# ------------------------------------------------------------------ reports
def test_report_period_and_version_rules(db):
    user = make_user(db)
    from app.models import Report
    assert rejected(db, Report(year=2099, month=13, days_in_month=31, source_file_id=make_report(db, user).source_file_id))
    first = make_report(db, user, year=2098, month=3, version=1, status="active", is_current=True, days=31)
    assert rejected(db, Report(year=2098, month=3, version=2, status="active", is_current=True, days_in_month=31, source_file_id=make_report(db, user).source_file_id))
    assert rejected(db, Report(year=2098, month=3, version=1, days_in_month=31, source_file_id=first.source_file_id))
    assert rejected(db, Report(year=2098, month=4, version=1, status="draft", is_current=True, days_in_month=30, source_file_id=first.source_file_id))


def test_replacement_keeps_old_version_and_allows_one_current(db):
    from datetime import datetime, timezone
    from app.models import Report
    user = make_user(db)
    old = make_report(db, user, year=2097, month=10, version=1, status="active", is_current=True)
    # Controlled replacement: retire the old version, then add version 2 pointing at it.
    old.is_current = False
    old.status = "superseded"
    old.superseded_at = datetime.now(timezone.utc)
    db.flush()
    new = make_report(db, user, year=2097, month=10, version=2, status="active", is_current=True)
    new.supersedes_report_id = old.id
    db.flush()
    assert db.scalar(select(func.count()).select_from(Report).where(Report.year == 2097, Report.is_current.is_(True))) == 1
    assert new.supersedes.id == old.id


# ------------------------------------------------------------------ daily km
def _rv(db):
    user = make_user(db)
    return make_report_vehicle(db, make_report(db, user), make_vehicle(db))


def test_km_states_cannot_turn_offline_or_missing_into_zero(db):
    rv = _rv(db)
    d = lambda day: date(2099, 10, day)
    assert not rejected(db, DailyKm(report_vehicle_id=rv.id, reading_date=d(1), data_state="actual", km=Decimal("57.5"), source_text="57.5"))
    assert not rejected(db, DailyKm(report_vehicle_id=rv.id, reading_date=d(2), data_state="reported_zero", km=Decimal("0"), source_text="0"))
    assert not rejected(db, DailyKm(report_vehicle_id=rv.id, reading_date=d(3), data_state="gps_offline", km=None, source_text="Offline"))
    assert not rejected(db, DailyKm(report_vehicle_id=rv.id, reading_date=d(4), data_state="missing", km=None))
    assert not rejected(db, DailyKm(report_vehicle_id=rv.id, reading_date=d(5), data_state="invalid", km=None, source_text="abc"))
    assert rejected(db, DailyKm(report_vehicle_id=rv.id, reading_date=d(6), data_state="gps_offline", km=Decimal("0")))
    assert rejected(db, DailyKm(report_vehicle_id=rv.id, reading_date=d(7), data_state="missing", km=Decimal("0")))
    assert rejected(db, DailyKm(report_vehicle_id=rv.id, reading_date=d(8), data_state="actual", km=None))
    assert rejected(db, DailyKm(report_vehicle_id=rv.id, reading_date=d(9), data_state="actual", km=Decimal("0")))
    assert rejected(db, DailyKm(report_vehicle_id=rv.id, reading_date=d(10), data_state="reported_zero", km=Decimal("5")))


def test_one_reading_per_vehicle_per_date_and_every_calendar_day_is_storable(db):
    rv = _rv(db)
    assert not rejected(db, DailyKm(report_vehicle_id=rv.id, reading_date=date(2099, 10, 31), data_state="missing"))
    assert rejected(db, DailyKm(report_vehicle_id=rv.id, reading_date=date(2099, 10, 31), data_state="missing"))
    assert not rejected(db, DailyKm(report_vehicle_id=rv.id, reading_date=date(2096, 2, 29), data_state="missing"))


def test_daily_status_states(db):
    rv = _rv(db)
    running = StatusRepository(db).get_by_code("running")
    assert not rejected(db, DailyStatus(report_vehicle_id=rv.id, status_date=date(2099, 10, 1), source_text="RUNNING", match_state="recognized", status_definition_id=running.id))
    assert not rejected(db, DailyStatus(report_vehicle_id=rv.id, status_date=date(2099, 10, 2), source_text="To be Sold", match_state="unrecognized"))
    assert not rejected(db, DailyStatus(report_vehicle_id=rv.id, status_date=date(2099, 10, 3), source_text=None, match_state="missing"))
    assert rejected(db, DailyStatus(report_vehicle_id=rv.id, status_date=date(2099, 10, 4), source_text="x", match_state="recognized"))
    assert rejected(db, DailyStatus(report_vehicle_id=rv.id, status_date=date(2099, 10, 5), source_text="x", match_state="unrecognized", status_definition_id=running.id))
    assert rejected(db, DailyStatus(report_vehicle_id=rv.id, status_date=date(2099, 10, 1), source_text="Running", match_state="recognized", status_definition_id=running.id))


# ------------------------------------------------------------------ financials
def test_unavailable_financial_values_stay_null(db):
    rv = _rv(db)
    db.add(MonthlyFinancial(report_vehicle_id=rv.id))
    db.flush()
    row = db.execute(
        text("SELECT revenue, erp_km, trips, cars_lifted FROM monthly_financials WHERE report_vehicle_id = :i"),
        {"i": rv.id},
    ).one()
    assert tuple(row) == (None, None, None, None)  # NULL in the database, never 0
    assert rejected(db, MonthlyFinancial(report_vehicle_id=_rv(db).id, revenue=Decimal("-1")))


# ------------------------------------------------------------------ append-only history
def test_corrections_are_append_only_and_reversal_is_a_new_row(db):
    user = make_user(db)
    rv = _rv(db)
    repo = CorrectionRepository(db)
    first = repo.add_correction(target_table="daily_status", target_id="1", field_name="status",
                                original_value="Halting", corrected_value="Running", reason="Driver confirmed",
                                corrected_by_user_id=user.id, report_vehicle_id=rv.id)
    reversal = repo.reverse(first.id, "Entered by mistake", user.id)
    assert reversal.id != first.id and reversal.correction_type == "reversal"
    assert reversal.reverses_correction_id == first.id
    assert reversal.corrected_value == "Halting" and reversal.original_value == "Running"
    with pytest.raises(CorrectionError):
        repo.reverse(first.id, "again", user.id)
    with pytest.raises(CorrectionError):
        repo.reverse(reversal.id, "reverse the reversal", user.id)
    with pytest.raises(DBAPIError):
        with db.begin_nested():
            db.execute(text("UPDATE data_corrections SET reason = 'edited' WHERE id = :i"), {"i": first.id})
    with pytest.raises(DBAPIError):
        with db.begin_nested():
            db.execute(text("DELETE FROM data_corrections WHERE id = :i"), {"i": first.id})
    assert db.get(type(first), first.id).reason == "Driver confirmed"


def test_audit_log_is_append_only(db):
    user = make_user(db)
    entry = AuditRepository(db).record("user.create", "users", str(user.id), actor=user, after={"email": user.email})
    assert entry.actor_email == user.email
    with pytest.raises(DBAPIError):
        with db.begin_nested():
            db.execute(text("UPDATE audit_log SET action = 'x' WHERE id = :i"), {"i": entry.id})
    with pytest.raises(DBAPIError):
        with db.begin_nested():
            db.execute(text("DELETE FROM audit_log WHERE id = :i"), {"i": entry.id})


def test_original_imported_daily_data_cannot_be_updated_or_deleted(db):
    rv = _rv(db)
    row = DailyKm(report_vehicle_id=rv.id, reading_date=date(2099, 10, 1), data_state="gps_offline", source_text="Offline")
    db.add(row)
    db.flush()
    for sql in ("UPDATE daily_km SET km = 0 WHERE id = :i", "DELETE FROM daily_km WHERE id = :i"):
        with pytest.raises(DBAPIError):
            with db.begin_nested():
                db.execute(text(sql), {"i": row.id})


def test_historical_reports_cannot_be_deleted(db):
    user = make_user(db)
    report = make_report(db, user)
    with pytest.raises(DBAPIError):
        with db.begin_nested():
            db.execute(text("DELETE FROM reports WHERE id = :i"), {"i": report.id})
