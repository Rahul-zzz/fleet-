"""Small helpers that create valid rows with unique values (no real data, no real secrets)."""
import random
import uuid

from sqlalchemy.orm import Session

from app.models import Report, ReportVehicle, UploadedFile, User, Vehicle

# Looks like an Argon2 hash so it satisfies the format CHECK; it is not a real credential.
FAKE_HASH = "$argon2id$v=19$m=65536,t=3,p=4$" + "A" * 40


def make_user(db: Session, role: str = "analyst") -> User:
    user = User(email=f"{uuid.uuid4().hex}@example.test", full_name="Test User", password_hash=FAKE_HASH, role=role)
    db.add(user)
    db.flush()
    return user


def make_file(db: Session, user: User) -> UploadedFile:
    file = UploadedFile(
        original_filename="test.xlsx",
        file_extension=".xlsx",
        size_bytes=1000,
        sha256=uuid.uuid4().hex + uuid.uuid4().hex,
        storage_ref=f"test/{uuid.uuid4().hex}",
        uploaded_by_user_id=user.id,
    )
    db.add(file)
    db.flush()
    return file


def make_report(db: Session, user: User, year: int = 2099, month: int = 10, version: int | None = None,
                status: str = "draft", is_current: bool = False, days: int = 31) -> Report:
    # Random version keeps (year, month, version) unique between helper calls.
    version = version if version is not None else random.randint(1, 2_000_000_000)
    report = Report(year=year, month=month, version=version, status=status, is_current=is_current,
                    days_in_month=days, source_file_id=make_file(db, user).id)
    db.add(report)
    db.flush()
    return report


def make_vehicle(db: Session) -> Vehicle:
    vehicle = Vehicle(reg_no="TST" + uuid.uuid4().hex[:9].upper())
    db.add(vehicle)
    db.flush()
    return vehicle


def make_report_vehicle(db: Session, report: Report, vehicle: Vehicle) -> ReportVehicle:
    rv = ReportVehicle(report_id=report.id, vehicle_id=vehicle.id, reg_no_as_imported=vehicle.reg_no)
    db.add(rv)
    db.flush()
    return rv
