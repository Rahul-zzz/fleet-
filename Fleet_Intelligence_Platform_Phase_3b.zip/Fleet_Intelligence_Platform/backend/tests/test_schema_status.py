import pytest

from app.services.schema_status import evaluate_schema_status


@pytest.mark.parametrize(
    ("current", "head", "expected_tables", "present", "result"),
    [
        (None, "0002", 22, 0, "not_initialized"),
        ("0001", "0002", 22, 0, "outdated"),
        ("0002", "0002", 22, 20, "incomplete"),
        ("0002", "0002", 22, 22, "ok"),
        ("0002", None, 22, 22, "ok"),  # head unknown (migrations not shipped): judge by tables
    ],
)
def test_evaluate_schema_status(current, head, expected_tables, present, result):
    assert evaluate_schema_status(current, head, expected_tables, present) == result
