from datetime import datetime, timezone
from decimal import Decimal
from types import SimpleNamespace

from app.schemas.daily import DailyKmRead
from app.schemas.user import UserRead


def test_user_schema_never_exposes_password_hash():
    assert "password_hash" not in UserRead.model_fields
    user = SimpleNamespace(
        id="00000000-0000-0000-0000-000000000001",
        email="a@example.test",
        full_name="A",
        role="admin",
        is_active=True,
        last_login_at=None,
        created_at=datetime.now(timezone.utc),
        password_hash="$argon2id$should-not-leak",
    )
    dumped = UserRead.model_validate(user).model_dump()
    assert "password_hash" not in dumped


def test_daily_km_schema_keeps_offline_as_none_not_zero():
    row = SimpleNamespace(
        reading_date="2026-10-31", data_state="gps_offline", km=None, source_text="Offline"
    )
    parsed = DailyKmRead.model_validate(row)
    assert parsed.km is None
    assert parsed.data_state == "gps_offline"
    zero = DailyKmRead.model_validate(
        SimpleNamespace(reading_date="2026-10-01", data_state="reported_zero", km=Decimal("0"), source_text="0")
    )
    assert zero.km == Decimal("0")
