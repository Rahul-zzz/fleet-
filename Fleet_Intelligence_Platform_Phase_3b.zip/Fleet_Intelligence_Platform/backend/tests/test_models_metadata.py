"""Structure checks on the ORM models. They need SQLAlchemy but NO database."""
import pytest
from sqlalchemy import CheckConstraint, DateTime, Numeric, UniqueConstraint
from sqlalchemy.orm import configure_mappers

import app.models  # noqa: F401
from app.database.base import Base
from app.models import enums

EXPECTED_TABLES = {
    "users", "audit_log", "uploaded_files", "import_profiles", "reports", "import_raw_rows",
    "import_issues", "vehicles", "report_vehicles", "daily_km", "daily_status",
    "monthly_financials", "status_definitions", "status_aliases", "status_definition_history",
    "data_corrections", "vehicle_metrics", "report_metrics", "ai_conversations", "ai_messages",
    "ai_reports", "settings",
}


def _checks(table):
    return {c.name: str(c.sqltext) for c in table.constraints if isinstance(c, CheckConstraint)}


def _ck(table_name, short):
    """Constraint name with or without the naming-convention prefix."""
    names = _checks(Base.metadata.tables[table_name])
    return names.get(f"ck_{table_name}_{short}") or names.get(short)


def test_all_expected_tables_are_registered():
    assert set(Base.metadata.tables) == EXPECTED_TABLES


def test_mappers_and_relationships_configure():
    configure_mappers()


def test_every_foreign_key_points_to_a_real_column_and_never_cascades():
    for table in Base.metadata.tables.values():
        for fk in table.foreign_keys:
            assert fk.column.table.name in EXPECTED_TABLES
            assert fk.ondelete == "RESTRICT", f"{table.name}.{fk.parent.name} must be RESTRICT"


def test_unique_rules_exist():
    def uniques(name):
        return {tuple(c.name for c in u.columns) for u in Base.metadata.tables[name].constraints if isinstance(u, UniqueConstraint)}

    assert ("reg_no",) in uniques("vehicles")
    assert ("sha256",) in uniques("uploaded_files")
    assert ("report_vehicle_id", "reading_date") in uniques("daily_km")
    assert ("report_vehicle_id", "status_date") in uniques("daily_status")
    assert ("report_id", "vehicle_id") in uniques("report_vehicles")
    assert ("year", "month", "version") in uniques("reports")
    assert ("reverses_correction_id",) in uniques("data_corrections")


def test_only_one_current_report_per_month_is_enforced_by_a_partial_unique_index():
    indexes = {i.name: i for i in Base.metadata.tables["reports"].indexes}
    index = indexes["uq_reports_current_year_month"]
    assert index.unique and [c.name for c in index.columns] == ["year", "month"]


def test_timestamps_are_timezone_aware():
    names = {"created_at", "updated_at", "occurred_at", "corrected_at", "uploaded_at", "calculated_at"}
    for table in Base.metadata.tables.values():
        for column in table.columns:
            if column.name in names:
                assert isinstance(column.type, DateTime) and column.type.timezone, f"{table.name}.{column.name}"


def test_km_and_money_are_numeric_and_nullable_without_default():
    km = Base.metadata.tables["daily_km"].c.km
    assert isinstance(km.type, Numeric) and km.nullable and km.server_default is None
    fin = Base.metadata.tables["monthly_financials"]
    for name in ("revenue", "erp_km", "trips", "cars_lifted"):
        assert fin.c[name].nullable and fin.c[name].server_default is None, name
    assert isinstance(fin.c.revenue.type, Numeric) and isinstance(fin.c.erp_km.type, Numeric)


@pytest.mark.parametrize(
    ("table", "short", "enum"),
    [
        ("users", "role", enums.UserRole),
        ("uploaded_files", "status", enums.UploadStatus),
        ("reports", "status", enums.ReportStatus),
        ("import_issues", "severity", enums.IssueSeverity),
        ("daily_km", "data_state", enums.KmDataState),
        ("daily_status", "match_state", enums.StatusMatchState),
        ("status_definitions", "category", enums.StatusCategory),
        ("data_corrections", "correction_type", enums.CorrectionType),
        ("data_corrections", "target_table", enums.CorrectionTarget),
        ("ai_messages", "role", enums.MessageRole),
        ("ai_messages", "channel", enums.MessageChannel),
        ("ai_reports", "kind", enums.AiReportKind),
    ],
)
def test_enum_values_match_check_constraints(table, short, enum):
    import re

    text = _ck(table, short)
    assert text is not None
    assert set(re.findall(r"'([^']+)'", text)) == {m.value for m in enum}


def test_daily_km_rule_text_forbids_offline_or_missing_as_zero():
    text = _ck("daily_km", "km_matches_state")
    assert "'gps_offline', 'missing', 'invalid') AND km IS NULL" in text
    assert "data_state = 'reported_zero' AND km IS NOT NULL AND km = 0" in text


def test_password_hash_is_the_only_credential_column_on_users():
    cols = Base.metadata.tables["users"].c.keys()
    assert "password_hash" in cols
    assert "password" not in cols
