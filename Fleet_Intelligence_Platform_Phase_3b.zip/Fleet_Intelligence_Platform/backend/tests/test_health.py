import pytest
from fastapi.testclient import TestClient
from sqlalchemy.exc import OperationalError

from app.database.session import get_db
from app.main import app

client = TestClient(app)


class _WorkingSession:
    def execute(self, *args, **kwargs):
        return 1


class _BrokenSession:
    def execute(self, *args, **kwargs):
        raise OperationalError("SELECT 1", {}, Exception("connection refused"))


def _with_session(session):
    def override():
        yield session

    app.dependency_overrides[get_db] = override


@pytest.fixture(autouse=True)
def _clear_overrides():
    yield
    app.dependency_overrides.clear()


def test_health_returns_ok():
    response = client.get("/api/v1/health")
    assert response.status_code == 200
    body = response.json()
    assert body["status"] == "ok"
    assert body["service"] == "FLEETIQ API"
    assert "timestamp" in body


def test_db_health_ok_when_database_responds():
    _with_session(_WorkingSession())
    response = client.get("/api/v1/health/db")
    assert response.status_code == 200
    assert response.json() == {"status": "ok", "database": "connected"}


def test_db_health_503_without_leaking_details():
    _with_session(_BrokenSession())
    response = client.get("/api/v1/health/db")
    assert response.status_code == 503
    assert response.json() == {"detail": "Database unavailable"}


@pytest.mark.integration
def test_db_health_against_real_postgres():
    """Needs PostgreSQL running (docker compose up -d) and a matching backend/.env."""
    response = client.get("/api/v1/health/db")
    assert response.status_code == 200
    assert response.json()["database"] == "connected"
