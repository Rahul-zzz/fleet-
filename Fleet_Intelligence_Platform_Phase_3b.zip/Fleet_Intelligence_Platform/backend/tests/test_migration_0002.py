"""Compares migration 0002 with the models WITHOUT a database.

The migration is executed against a recording stand-in for ``alembic.op`` that builds real
SQLAlchemy Table objects, then the result is compared with ``Base.metadata``.
"""
import importlib.util
import re
from pathlib import Path

import pytest
from sqlalchemy import CheckConstraint, ForeignKeyConstraint, MetaData, Table, UniqueConstraint

import app.models  # noqa: F401
from app.database.base import Base
from app.database.seed import DEFAULT_STATUS_DEFINITIONS

VERSIONS = Path(__file__).resolve().parents[2] / "database" / "migrations" / "versions"


class RecordingOp:
    def __init__(self):
        self.metadata = MetaData()
        self.indexes = []
        self.executed = []
        self.bulk = []
        self.dropped = []

    def f(self, name):
        return name

    def create_table(self, name, *items):
        Table(name, self.metadata, *items)

    def create_index(self, name, table, columns, unique=False, postgresql_where=None):
        where = str(postgresql_where) if postgresql_where is not None else None
        self.indexes.append((name, table, tuple(columns), unique, where))

    def execute(self, sql):
        self.executed.append(str(sql))

    def bulk_insert(self, table, rows):
        self.bulk.append(rows)

    def drop_table(self, name):
        self.dropped.append(name)


def _load(filename):
    spec = importlib.util.spec_from_file_location(filename, VERSIONS / filename)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


@pytest.fixture(scope="module")
def migration():
    module = _load("20261123_0002_phase3b_schema.py")
    recorder = RecordingOp()
    module.op = recorder
    module.upgrade()
    return module, recorder


def _norm(text):
    return re.sub(r"\s+", " ", str(text).strip())


def _full_ck(table, name):
    return name if name.startswith("ck_") else f"ck_{table}_{name}"


def test_revision_chain():
    baseline = _load("20261123_0001_baseline.py")
    module = _load("20261123_0002_phase3b_schema.py")
    assert baseline.revision == "0001" and baseline.down_revision is None
    assert module.revision == "0002" and module.down_revision == "0001"


def test_same_tables_as_models(migration):
    _, rec = migration
    assert set(rec.metadata.tables) == set(Base.metadata.tables)


def test_columns_match_models(migration):
    _, rec = migration
    for name, model_table in Base.metadata.tables.items():
        mig_table = rec.metadata.tables[name]
        assert set(mig_table.c.keys()) == set(model_table.c.keys()), name
        for col in model_table.c:
            assert mig_table.c[col.name].nullable == col.nullable, f"{name}.{col.name}"


def test_foreign_keys_match_models(migration):
    _, rec = migration
    for name, model_table in Base.metadata.tables.items():
        def fks(table):
            return {(fk.parent.name, fk.target_fullname, fk.ondelete) for fk in table.foreign_keys}

        assert fks(rec.metadata.tables[name]) == fks(model_table), name


def test_check_unique_and_index_definitions_match_models(migration):
    _, rec = migration
    for name, model_table in Base.metadata.tables.items():
        mig_table = rec.metadata.tables[name]
        m_checks = {_full_ck(name, c.name): _norm(c.sqltext) for c in model_table.constraints if isinstance(c, CheckConstraint)}
        g_checks = {_full_ck(name, c.name): _norm(c.sqltext) for c in mig_table.constraints if isinstance(c, CheckConstraint)}
        assert m_checks == g_checks, name
        m_uq = {c.name: [x.name for x in c.columns] for c in model_table.constraints if isinstance(c, UniqueConstraint)}
        g_uq = {c.name: [x.name for x in c.columns] for c in mig_table.constraints if isinstance(c, UniqueConstraint)}
        assert m_uq == g_uq, name
        m_ix = {i.name: (tuple(c.name for c in i.columns), bool(i.unique)) for i in model_table.indexes}
        g_ix = {n: (cols, u) for n, t, cols, u, _ in rec.indexes if t == name}
        assert m_ix == g_ix, name


def test_seed_matches_approved_statuses(migration):
    module, rec = migration
    seed = [(c, n, cat) for c, n, cat, _, _ in module.STATUS_SEED]
    assert seed == list(DEFAULT_STATUS_DEFINITIONS)
    assert len(rec.bulk) == 1 and len(rec.bulk[0]) == 11
    categories = [cat for _, _, cat in seed]
    assert (categories.count("utilized"), categories.count("unutilized"), categories.count("unclassified")) == (5, 5, 1)
    assert not any("sold" in name.lower() for _, name, _ in seed)


def test_downgrade_drops_children_before_parents(migration):
    module, _ = migration
    rec = RecordingOp()
    module.op = rec
    module.downgrade()
    assert rec.dropped == list(reversed(module.TABLES))
    assert set(module.TABLES) == set(Base.metadata.tables)
