import pytest

from app.utils.status_text import normalize_status_text


@pytest.mark.parametrize(
    ("raw", "expected"),
    [
        ("Running", "running"),
        ("  Waiting for   LOAD ", "waiting for load"),
        ("waiting for lOAD", "waiting for load"),
        ("No Driver Assigned", "no driver assigned"),
        ("driver home", "driver home"),
        (0, "0"),
    ],
)
def test_normalizes_spelling_variants(raw, expected):
    assert normalize_status_text(raw) == expected


@pytest.mark.parametrize("blank", [None, "", "   ", "\t\n"])
def test_blank_is_none(blank):
    assert normalize_status_text(blank) is None
