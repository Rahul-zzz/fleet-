import os
from pathlib import Path

# Unit tests must be able to import the app even without a backend/.env file.
# This placeholder is never used to connect anywhere (unit tests override get_db).
_ENV_FILE = Path(__file__).resolve().parents[1] / ".env"
if not os.getenv("DATABASE_URL") and not _ENV_FILE.exists():
    os.environ["DATABASE_URL"] = "postgresql+psycopg://user:pass@127.0.0.1:5432/test"
