"""Calendar helpers: every calendar day of a month, including day 31 and 29 February."""
import calendar
from datetime import date


def validate_period(year: int, month: int) -> None:
    if not 2000 <= year <= 2100:
        raise ValueError(f"year {year} is outside 2000-2100")
    if not 1 <= month <= 12:
        raise ValueError(f"month {month} is outside 1-12")


def days_in_month(year: int, month: int) -> int:
    validate_period(year, month)
    return calendar.monthrange(year, month)[1]


def dates_in_month(year: int, month: int) -> list[date]:
    """All calendar dates of the month, in order."""
    return [date(year, month, day) for day in range(1, days_in_month(year, month) + 1)]
