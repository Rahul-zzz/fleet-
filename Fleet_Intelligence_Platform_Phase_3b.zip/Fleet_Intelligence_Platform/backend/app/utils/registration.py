"""Canonical vehicle registration numbers.

The canonical form is upper case letters and digits only (no spaces, hyphens or other
punctuation), 4 to 20 characters. It matches the CHECK constraint on vehicles.reg_no.
Registration numbers are the ONLY key used to match vehicles across sheets and months;
row order and S.No are never used.
"""
import re

_NON_ALNUM = re.compile(r"[^A-Za-z0-9]")
_CANONICAL = re.compile(r"^[A-Z0-9]{4,20}$")


class InvalidRegistrationError(ValueError):
    """The value cannot be turned into a canonical registration number."""


def normalize_registration(value: object) -> str:
    """Return the canonical registration number or raise InvalidRegistrationError.

    Letters are never substituted (for example O is not turned into 0).
    """
    if value is None:
        raise InvalidRegistrationError("registration number is empty")
    canonical = _NON_ALNUM.sub("", str(value)).upper()
    if not _CANONICAL.match(canonical):
        raise InvalidRegistrationError(
            f"{str(value)!r} is not a valid registration number (4-20 letters/digits)"
        )
    return canonical


def try_normalize_registration(value: object) -> str | None:
    """Like normalize_registration but returns None instead of raising."""
    try:
        return normalize_registration(value)
    except InvalidRegistrationError:
        return None
