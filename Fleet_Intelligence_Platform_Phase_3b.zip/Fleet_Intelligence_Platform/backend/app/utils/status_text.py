"""Normalization used to match imported status text against status aliases."""


def normalize_status_text(value: object) -> str | None:
    """Trim, collapse inner whitespace and lower-case. Blank or None gives None.

    Example: '  Waiting for   LOAD ' -> 'waiting for load'.
    Unknown text is NOT classified here; the caller records it as unrecognized.
    """
    if value is None:
        return None
    collapsed = " ".join(str(value).split())
    if not collapsed:
        return None
    return collapsed.casefold()
