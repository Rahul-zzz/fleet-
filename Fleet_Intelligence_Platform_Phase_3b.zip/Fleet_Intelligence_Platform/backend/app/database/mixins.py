"""Reusable column groups for the ORM models.

All timestamps are timezone-aware and stored in UTC (PostgreSQL ``timestamptz``).
"""
import uuid
from datetime import datetime

from sqlalchemy import BigInteger, DateTime, Identity, Integer, func, text
from sqlalchemy.orm import Mapped, mapped_column


class UUIDPrimaryKeyMixin:
    id: Mapped[uuid.UUID] = mapped_column(
        primary_key=True, default=uuid.uuid4, server_default=text("gen_random_uuid()")
    )


class BigIntPrimaryKeyMixin:
    """For high-volume tables (daily data, logs)."""

    id: Mapped[int] = mapped_column(BigInteger, Identity(), primary_key=True)


class IntPrimaryKeyMixin:
    """For small configuration tables."""

    id: Mapped[int] = mapped_column(Integer, Identity(), primary_key=True)


class CreatedAtMixin:
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )


class TimestampMixin(CreatedAtMixin):
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now(),
        nullable=False,
    )
