"""Approved default status definitions.

The Alembic migration 0002 contains its own frozen copy of this data (migrations must
not depend on application code). A unit test keeps the two identical. This constant is
also what the application uses to check that the seed is present.
"""
from app.models.enums import StatusCategory

# (code, display name, category)
DEFAULT_STATUS_DEFINITIONS: tuple[tuple[str, str, str], ...] = (
    ("running", "Running", StatusCategory.UTILIZED.value),
    ("empty_running", "Empty Running", StatusCategory.UTILIZED.value),
    ("unloading", "Unloading", StatusCategory.UTILIZED.value),
    ("load_allotted", "Load Allotted", StatusCategory.UTILIZED.value),
    ("waiting_for_dispatch", "Waiting for Dispatch", StatusCategory.UTILIZED.value),
    ("waiting_for_load", "Waiting for Load", StatusCategory.UNUTILIZED.value),
    ("under_maintenance", "Under Maintenance", StatusCategory.UNUTILIZED.value),
    ("accident", "Accident", StatusCategory.UNUTILIZED.value),
    ("halting", "Halting", StatusCategory.UNUTILIZED.value),
    ("no_driver_assigned", "No Driver Assigned", StatusCategory.UNUTILIZED.value),
    ("driver_home", "Driver Home", StatusCategory.UNCLASSIFIED.value),
)
