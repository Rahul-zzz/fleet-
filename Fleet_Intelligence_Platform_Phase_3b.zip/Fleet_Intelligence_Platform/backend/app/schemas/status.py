from app.schemas.common import ORMSchema


class StatusAliasRead(ORMSchema):
    id: int
    alias_normalized: str
    alias_display: str
    is_active: bool


class StatusDefinitionRead(ORMSchema):
    id: int
    code: str
    display_name: str
    category: str
    sort_order: int
    is_active: bool
    is_system: bool
    description: str | None
