import uuid
from datetime import datetime

from app.schemas.common import ORMSchema


class UserRead(ORMSchema):
    """Public view of a user. The password hash is deliberately NOT a field."""

    id: uuid.UUID
    email: str
    full_name: str
    role: str
    is_active: bool
    last_login_at: datetime | None
    created_at: datetime
