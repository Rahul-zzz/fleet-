import uuid
from datetime import datetime

from app.schemas.common import ORMSchema


class ReportRead(ORMSchema):
    id: uuid.UUID
    year: int
    month: int
    version: int
    status: str
    is_current: bool
    days_in_month: int
    supersedes_report_id: uuid.UUID | None
    superseded_at: datetime | None
    created_at: datetime
