import uuid
from datetime import datetime
from typing import Any

from app.schemas.common import ORMSchema


class DataCorrectionRead(ORMSchema):
    id: int
    target_table: str
    target_id: str
    field_name: str
    original_value: Any | None
    corrected_value: Any | None
    reason: str
    correction_type: str
    corrected_by_user_id: uuid.UUID
    corrected_at: datetime
    reverses_correction_id: int | None
    supersedes_correction_id: int | None
