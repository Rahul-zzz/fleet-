import uuid

from app.schemas.common import ORMSchema


class VehicleRead(ORMSchema):
    id: uuid.UUID
    reg_no: str
    route: str | None
    vehicle_type: str | None
    is_active: bool
