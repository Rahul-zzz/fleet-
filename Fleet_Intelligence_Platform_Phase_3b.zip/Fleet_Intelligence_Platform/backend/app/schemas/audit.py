from datetime import datetime
from typing import Any

from app.schemas.common import ORMSchema


class AuditLogRead(ORMSchema):
    id: int
    occurred_at: datetime
    actor_email: str | None
    action: str
    entity_type: str
    entity_id: str | None
    before_data: dict[str, Any] | None
    after_data: dict[str, Any] | None
    details: dict[str, Any] | None
