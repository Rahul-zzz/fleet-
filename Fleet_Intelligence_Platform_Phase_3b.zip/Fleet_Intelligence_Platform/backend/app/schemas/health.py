from pydantic import BaseModel


class HealthResponse(BaseModel):
    status: str
    service: str
    environment: str
    version: str
    timestamp: str


class DatabaseHealthResponse(BaseModel):
    status: str
    database: str
