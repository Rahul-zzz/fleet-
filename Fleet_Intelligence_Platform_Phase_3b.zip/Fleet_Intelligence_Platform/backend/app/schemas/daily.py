from datetime import date
from decimal import Decimal

from app.schemas.common import ORMSchema


class DailyKmRead(ORMSchema):
    """km is None for gps_offline, missing and invalid: it is never silently 0."""

    reading_date: date
    data_state: str
    km: Decimal | None
    source_text: str | None


class DailyStatusRead(ORMSchema):
    status_date: date
    match_state: str
    source_text: str | None
    status_definition_id: int | None
