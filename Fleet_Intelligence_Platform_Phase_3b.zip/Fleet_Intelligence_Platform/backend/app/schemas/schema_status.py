from pydantic import BaseModel


class SchemaStatusResponse(BaseModel):
    """Safe summary of the database schema state. No table names, credentials or errors."""

    status: str  # ok | not_initialized | outdated | incomplete
    current_revision: str | None
    head_revision: str | None
    expected_table_count: int
    present_table_count: int
