import uuid
from datetime import datetime
from typing import Any

from sqlalchemy import CheckConstraint, DateTime, ForeignKey, Index, String, func
from sqlalchemy.dialects.postgresql import INET, JSONB
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database.base import Base
from app.database.mixins import BigIntPrimaryKeyMixin
from app.models.user import User


class AuditLog(BigIntPrimaryKeyMixin, Base):
    """Append-only audit trail (a database trigger rejects UPDATE and DELETE)."""

    __tablename__ = "audit_log"

    occurred_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    actor_user_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("users.id", ondelete="RESTRICT"))
    actor_email: Mapped[str | None] = mapped_column(String(320))  # snapshot at the time
    action: Mapped[str] = mapped_column(String(100), nullable=False)
    entity_type: Mapped[str] = mapped_column(String(100), nullable=False)
    entity_id: Mapped[str | None] = mapped_column(String(100))
    before_data: Mapped[dict[str, Any] | None] = mapped_column(JSONB(none_as_null=True))
    after_data: Mapped[dict[str, Any] | None] = mapped_column(JSONB(none_as_null=True))
    details: Mapped[dict[str, Any] | None] = mapped_column(JSONB(none_as_null=True))
    ip_address: Mapped[str | None] = mapped_column(INET)
    request_id: Mapped[str | None] = mapped_column(String(100))

    actor: Mapped[User | None] = relationship(User)

    __table_args__ = (
        CheckConstraint("length(btrim(action)) > 0", name="action_not_blank"),
        CheckConstraint("length(btrim(entity_type)) > 0", name="entity_type_not_blank"),
        Index("ix_audit_log_occurred_at", "occurred_at"),
        Index("ix_audit_log_entity", "entity_type", "entity_id"),
        Index("ix_audit_log_actor_user_id_occurred_at", "actor_user_id", "occurred_at"),
        Index("ix_audit_log_action", "action"),
    )
