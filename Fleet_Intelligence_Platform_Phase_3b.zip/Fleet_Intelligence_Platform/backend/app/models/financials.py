import uuid
from decimal import Decimal
from typing import Any

from sqlalchemy import (
    CheckConstraint,
    ForeignKey,
    Integer,
    Numeric,
    String,
    UniqueConstraint,
)
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database.base import Base
from app.database.mixins import BigIntPrimaryKeyMixin, CreatedAtMixin
from app.models.vehicles import ReportVehicle


class MonthlyFinancial(BigIntPrimaryKeyMixin, CreatedAtMixin, Base):
    """Revenue, ERP km, trips and cars for one vehicle in one report.

    Every value is nullable: NULL means "Not Available" and is never stored as 0.
    No derived metric (such as revenue per km) is stored or computed here.
    """

    __tablename__ = "monthly_financials"

    report_vehicle_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("report_vehicles.id", ondelete="RESTRICT"), nullable=False
    )
    revenue: Mapped[Decimal | None] = mapped_column(Numeric(14, 2))
    erp_km: Mapped[Decimal | None] = mapped_column(Numeric(12, 2))
    trips: Mapped[int | None] = mapped_column(Integer)
    cars_lifted: Mapped[int | None] = mapped_column(Integer)
    source_sheet: Mapped[str | None] = mapped_column(String(255))
    source_values: Mapped[dict[str, Any] | None] = mapped_column(JSONB(none_as_null=True))

    report_vehicle: Mapped[ReportVehicle] = relationship(ReportVehicle)

    __table_args__ = (
        UniqueConstraint(
            "report_vehicle_id", name="uq_monthly_financials_report_vehicle_id"
        ),
        CheckConstraint("revenue IS NULL OR revenue >= 0", name="revenue_nonnegative"),
        CheckConstraint("erp_km IS NULL OR erp_km >= 0", name="erp_km_nonnegative"),
        CheckConstraint("trips IS NULL OR trips >= 0", name="trips_nonnegative"),
        CheckConstraint(
            "cars_lifted IS NULL OR cars_lifted >= 0", name="cars_lifted_nonnegative"
        ),
    )
