"""ORM models. Importing this package registers every table on ``Base.metadata``
(Alembic's env.py and the schema-status service rely on that)."""
from app.models.ai import AiConversation, AiMessage, AiReport
from app.models.audit import AuditLog
from app.models.corrections import DataCorrection
from app.models.daily import DailyKm, DailyStatus
from app.models.files import ImportIssue, ImportProfile, ImportRawRow, UploadedFile
from app.models.financials import MonthlyFinancial
from app.models.metrics import ReportMetric, VehicleMetric
from app.models.reports import Report
from app.models.settings import Setting
from app.models.status import StatusAlias, StatusDefinition, StatusDefinitionHistory
from app.models.user import User
from app.models.vehicles import ReportVehicle, Vehicle

__all__ = [
    "AiConversation",
    "AiMessage",
    "AiReport",
    "AuditLog",
    "DailyKm",
    "DailyStatus",
    "DataCorrection",
    "ImportIssue",
    "ImportProfile",
    "ImportRawRow",
    "MonthlyFinancial",
    "Report",
    "ReportMetric",
    "ReportVehicle",
    "Setting",
    "StatusAlias",
    "StatusDefinition",
    "StatusDefinitionHistory",
    "UploadedFile",
    "User",
    "Vehicle",
    "VehicleMetric",
]
