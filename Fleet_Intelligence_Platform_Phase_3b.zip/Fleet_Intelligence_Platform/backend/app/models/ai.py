import uuid
from datetime import datetime
from typing import Any

from sqlalchemy import (
    CheckConstraint,
    DateTime,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database.base import Base
from app.database.mixins import BigIntPrimaryKeyMixin, CreatedAtMixin, TimestampMixin, UUIDPrimaryKeyMixin


class AiConversation(UUIDPrimaryKeyMixin, TimestampMixin, Base):
    """A Fleet AI Copilot conversation (text and voice share one conversation).
    Structure only: no LLM or Copilot logic exists in Phase 3b."""

    __tablename__ = "ai_conversations"

    user_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("users.id", ondelete="RESTRICT"), nullable=False
    )
    title: Mapped[str | None] = mapped_column(String(255))
    context_state: Mapped[dict[str, Any] | None] = mapped_column(JSONB(none_as_null=True))
    archived_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

    messages: Mapped[list["AiMessage"]] = relationship(back_populates="conversation")

    __table_args__ = (Index("ix_ai_conversations_user_id", "user_id"),)


class AiMessage(BigIntPrimaryKeyMixin, CreatedAtMixin, Base):
    __tablename__ = "ai_messages"

    conversation_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("ai_conversations.id", ondelete="RESTRICT"), nullable=False
    )
    sequence: Mapped[int] = mapped_column(Integer, nullable=False)
    role: Mapped[str] = mapped_column(String(20), nullable=False)
    channel: Mapped[str] = mapped_column(String(10), nullable=False, server_default="text")
    content: Mapped[str | None] = mapped_column(Text)
    tool_calls: Mapped[Any | None] = mapped_column(JSONB(none_as_null=True))
    provider: Mapped[str | None] = mapped_column(String(50))
    model: Mapped[str | None] = mapped_column(String(100))
    token_usage: Mapped[dict[str, Any] | None] = mapped_column(JSONB(none_as_null=True))

    conversation: Mapped[AiConversation] = relationship(back_populates="messages")

    __table_args__ = (
        UniqueConstraint("conversation_id", "sequence", name="uq_ai_messages_conversation_id_sequence"),
        CheckConstraint("role IN ('user', 'assistant', 'tool', 'system')", name="role"),
        CheckConstraint("channel IN ('text', 'voice')", name="channel"),
        CheckConstraint("sequence >= 1", name="sequence_positive"),
        CheckConstraint("content IS NOT NULL OR tool_calls IS NOT NULL", name="has_content"),
    )


class AiReport(UUIDPrimaryKeyMixin, CreatedAtMixin, Base):
    """A generated narrative report. Numbers come from validated backend calculations
    and are recorded in source_figures so each report can be traced."""

    __tablename__ = "ai_reports"

    report_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("reports.id", ondelete="RESTRICT"), nullable=False
    )
    kind: Mapped[str] = mapped_column(String(40), nullable=False)
    narrative: Mapped[str] = mapped_column(Text, nullable=False)
    source_figures: Mapped[dict[str, Any] | None] = mapped_column(JSONB(none_as_null=True))
    calc_version: Mapped[str | None] = mapped_column(String(50))
    conversation_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("ai_conversations.id", ondelete="RESTRICT")
    )
    generated_by_user_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("users.id", ondelete="RESTRICT")
    )
    provider: Mapped[str | None] = mapped_column(String(50))
    model: Mapped[str | None] = mapped_column(String(100))

    __table_args__ = (
        CheckConstraint(
            "kind IN ('monthly_utilization', 'vehicle_performance', 'unutilized_vehicle',"
            " 'fleet_efficiency', 'executive_summary')",
            name="kind",
        ),
        Index("ix_ai_reports_report_id_kind", "report_id", "kind"),
    )
