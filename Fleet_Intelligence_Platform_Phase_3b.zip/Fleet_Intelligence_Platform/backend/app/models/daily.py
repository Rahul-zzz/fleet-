import uuid
from datetime import date
from decimal import Decimal

from sqlalchemy import (
    CheckConstraint,
    Date,
    ForeignKey,
    Index,
    Integer,
    Numeric,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database.base import Base
from app.database.mixins import BigIntPrimaryKeyMixin, CreatedAtMixin
from app.models.status import StatusAlias, StatusDefinition
from app.models.vehicles import ReportVehicle


class DailyKm(BigIntPrimaryKeyMixin, CreatedAtMixin, Base):
    """One vehicle-day of GPS kilometres, exactly as imported (append-only).

    ``data_state`` keeps Offline, Missing and Invalid distinct from zero:
      actual         km > 0
      reported_zero  km = 0
      gps_offline    km IS NULL (source said Offline)
      missing        km IS NULL (no reading)
      invalid        km IS NULL (unreadable value; see source_text)
    """

    __tablename__ = "daily_km"

    report_vehicle_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("report_vehicles.id", ondelete="RESTRICT"), nullable=False
    )
    reading_date: Mapped[date] = mapped_column(Date, nullable=False)
    source_text: Mapped[str | None] = mapped_column(Text)
    km: Mapped[Decimal | None] = mapped_column(Numeric(10, 2))
    data_state: Mapped[str] = mapped_column(String(20), nullable=False)
    source_sheet: Mapped[str | None] = mapped_column(String(255))
    source_row: Mapped[int | None] = mapped_column(Integer)
    source_column: Mapped[str | None] = mapped_column(String(20))

    report_vehicle: Mapped[ReportVehicle] = relationship(ReportVehicle)

    __table_args__ = (
        UniqueConstraint(
            "report_vehicle_id", "reading_date", name="uq_daily_km_report_vehicle_id_reading_date"
        ),
        CheckConstraint(
            "data_state IN ('actual', 'reported_zero', 'gps_offline', 'missing', 'invalid')",
            name="data_state",
        ),
        CheckConstraint(
            "(data_state = 'actual' AND km IS NOT NULL AND km > 0)"
            " OR (data_state = 'reported_zero' AND km IS NOT NULL AND km = 0)"
            " OR (data_state IN ('gps_offline', 'missing', 'invalid') AND km IS NULL)",
            name="km_matches_state",
        ),
        Index("ix_daily_km_reading_date_state", "reading_date", "data_state"),
    )


class DailyStatus(BigIntPrimaryKeyMixin, CreatedAtMixin, Base):
    """One vehicle-day of status, exactly as imported (append-only).

    ``source_text`` is the original text. ``status_definition_id`` is set only when the
    text matched an active alias; unknown text stays 'unrecognized' (never auto-classified)
    and an empty cell is 'missing'.
    """

    __tablename__ = "daily_status"

    report_vehicle_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("report_vehicles.id", ondelete="RESTRICT"), nullable=False
    )
    status_date: Mapped[date] = mapped_column(Date, nullable=False)
    source_text: Mapped[str | None] = mapped_column(Text)
    match_state: Mapped[str] = mapped_column(String(20), nullable=False)
    status_definition_id: Mapped[int | None] = mapped_column(
        ForeignKey("status_definitions.id", ondelete="RESTRICT")
    )
    matched_alias_id: Mapped[int | None] = mapped_column(
        ForeignKey("status_aliases.id", ondelete="RESTRICT")
    )
    source_sheet: Mapped[str | None] = mapped_column(String(255))
    source_row: Mapped[int | None] = mapped_column(Integer)
    source_column: Mapped[str | None] = mapped_column(String(20))

    report_vehicle: Mapped[ReportVehicle] = relationship(ReportVehicle)
    status_definition: Mapped[StatusDefinition | None] = relationship(StatusDefinition)
    matched_alias: Mapped[StatusAlias | None] = relationship(StatusAlias)

    __table_args__ = (
        UniqueConstraint(
            "report_vehicle_id",
            "status_date",
            name="uq_daily_status_report_vehicle_id_status_date",
        ),
        CheckConstraint(
            "match_state IN ('recognized', 'unrecognized', 'missing')", name="match_state"
        ),
        CheckConstraint(
            "(match_state = 'recognized' AND status_definition_id IS NOT NULL"
            " AND source_text IS NOT NULL AND btrim(source_text) <> '')"
            " OR (match_state = 'unrecognized' AND status_definition_id IS NULL"
            " AND matched_alias_id IS NULL AND source_text IS NOT NULL AND btrim(source_text) <> '')"
            " OR (match_state = 'missing' AND status_definition_id IS NULL"
            " AND matched_alias_id IS NULL AND source_text IS NULL)",
            name="definition_matches_state",
        ),
        Index("ix_daily_status_status_date", "status_date"),
        Index("ix_daily_status_status_definition_id", "status_definition_id"),
    )
