import uuid
from typing import Any

from sqlalchemy import ForeignKey, String, Text
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column

from app.database.base import Base
from app.database.mixins import TimestampMixin


class Setting(TimestampMixin, Base):
    """Application configuration as key/value (JSONB). Phase 3b seeds no values:
    thresholds such as the low-activity km level are added when they are used."""

    __tablename__ = "settings"

    setting_key: Mapped[str] = mapped_column(String(150), primary_key=True)
    value: Mapped[Any] = mapped_column(JSONB, nullable=False)
    description: Mapped[str | None] = mapped_column(Text)
    updated_by_user_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("users.id", ondelete="RESTRICT")
    )

