import uuid
from datetime import datetime
from typing import Any

from sqlalchemy import (
    BigInteger,
    Boolean,
    CheckConstraint,
    DateTime,
    ForeignKey,
    Index,
    Integer,
    SmallInteger,
    String,
    Text,
    UniqueConstraint,
    func,
    text,
)
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database.base import Base
from app.database.mixins import (
    BigIntPrimaryKeyMixin,
    CreatedAtMixin,
    TimestampMixin,
    UUIDPrimaryKeyMixin,
)
from app.models.enums import UploadStatus


class ImportProfile(UUIDPrimaryKeyMixin, TimestampMixin, Base):
    """Versioned, configurable mapping of worksheets and columns (stored as JSONB)."""

    __tablename__ = "import_profiles"

    name: Mapped[str] = mapped_column(String(150), nullable=False)
    version: Mapped[int] = mapped_column(Integer, nullable=False, server_default="1")
    description: Mapped[str | None] = mapped_column(Text)
    config: Mapped[dict[str, Any]] = mapped_column(
        JSONB, nullable=False, server_default=text("'{}'::jsonb")
    )
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, server_default="true")
    created_by_user_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("users.id", ondelete="RESTRICT")
    )

    __table_args__ = (
        UniqueConstraint("name", "version", name="uq_import_profiles_name_version"),
        CheckConstraint("version >= 1", name="version_positive"),
    )


class UploadedFile(UUIDPrimaryKeyMixin, TimestampMixin, Base):
    """Metadata of an uploaded workbook. The file itself lives in storage (storage_ref).

    Macros are never executed; ``contains_macros`` is only a detected flag.
    """

    __tablename__ = "uploaded_files"

    original_filename: Mapped[str] = mapped_column(String(512), nullable=False)
    file_extension: Mapped[str] = mapped_column(String(10), nullable=False)
    content_type: Mapped[str | None] = mapped_column(String(255))
    size_bytes: Mapped[int] = mapped_column(BigInteger, nullable=False)
    sha256: Mapped[str] = mapped_column(String(64), nullable=False)
    storage_ref: Mapped[str] = mapped_column(String(1024), nullable=False)
    status: Mapped[str] = mapped_column(
        String(20),
        nullable=False,
        default=UploadStatus.UPLOADED.value,
        server_default="uploaded",
    )
    contains_macros: Mapped[bool | None] = mapped_column(Boolean)
    import_profile_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("import_profiles.id", ondelete="RESTRICT")
    )
    declared_year: Mapped[int | None] = mapped_column(SmallInteger)
    declared_month: Mapped[int | None] = mapped_column(SmallInteger)
    file_metadata: Mapped[dict[str, Any] | None] = mapped_column(JSONB(none_as_null=True))
    uploaded_by_user_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("users.id", ondelete="RESTRICT"), nullable=False
    )
    uploaded_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )

    import_profile: Mapped[ImportProfile | None] = relationship(ImportProfile)
    raw_rows: Mapped[list["ImportRawRow"]] = relationship(back_populates="uploaded_file")
    issues: Mapped[list["ImportIssue"]] = relationship(back_populates="uploaded_file")

    __table_args__ = (
        UniqueConstraint("sha256", name="uq_uploaded_files_sha256"),
        CheckConstraint("file_extension IN ('.xlsx', '.xlsm')", name="file_extension"),
        CheckConstraint("sha256 ~ '^[0-9a-f]{64}$'", name="sha256_format"),
        CheckConstraint("size_bytes > 0", name="size_bytes_positive"),
        CheckConstraint(
            "status IN ('uploaded', 'analyzed', 'committed', 'rejected', 'failed')",
            name="status",
        ),
        CheckConstraint(
            "declared_month IS NULL OR declared_month BETWEEN 1 AND 12",
            name="declared_month_range",
        ),
        CheckConstraint(
            "declared_year IS NULL OR declared_year BETWEEN 2000 AND 2100",
            name="declared_year_range",
        ),
        CheckConstraint(
            "(declared_year IS NULL) = (declared_month IS NULL)",
            name="declared_period_complete",
        ),
        Index("ix_uploaded_files_uploaded_by_user_id", "uploaded_by_user_id"),
        Index("ix_uploaded_files_status", "status"),
    )


class ImportRawRow(BigIntPrimaryKeyMixin, CreatedAtMixin, Base):
    """One source worksheet row exactly as read (append-only; protected by a trigger)."""

    __tablename__ = "import_raw_rows"

    uploaded_file_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("uploaded_files.id", ondelete="RESTRICT"), nullable=False
    )
    sheet_name: Mapped[str] = mapped_column(String(255), nullable=False)
    row_number: Mapped[int] = mapped_column(Integer, nullable=False)
    payload: Mapped[dict[str, Any]] = mapped_column(JSONB, nullable=False)

    uploaded_file: Mapped[UploadedFile] = relationship(back_populates="raw_rows")

    __table_args__ = (
        UniqueConstraint(
            "uploaded_file_id", "sheet_name", "row_number", name="uq_import_raw_rows_file_sheet_row"
        ),
        CheckConstraint("row_number >= 1", name="row_number_positive"),
    )


class ImportIssue(BigIntPrimaryKeyMixin, CreatedAtMixin, Base):
    """A validation warning or error found while importing."""

    __tablename__ = "import_issues"

    uploaded_file_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("uploaded_files.id", ondelete="RESTRICT"), nullable=False
    )
    report_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("reports.id", ondelete="RESTRICT")
    )
    severity: Mapped[str] = mapped_column(String(10), nullable=False)
    code: Mapped[str] = mapped_column(String(100), nullable=False)
    message: Mapped[str] = mapped_column(Text, nullable=False)
    sheet_name: Mapped[str | None] = mapped_column(String(255))
    row_number: Mapped[int | None] = mapped_column(Integer)
    column_ref: Mapped[str | None] = mapped_column(String(50))
    raw_value: Mapped[str | None] = mapped_column(Text)
    details: Mapped[dict[str, Any] | None] = mapped_column(JSONB(none_as_null=True))

    uploaded_file: Mapped[UploadedFile] = relationship(back_populates="issues")

    __table_args__ = (
        CheckConstraint("severity IN ('info', 'warning', 'error')", name="severity"),
        Index("ix_import_issues_file_severity", "uploaded_file_id", "severity"),
        Index("ix_import_issues_report_id", "report_id"),
        Index("ix_import_issues_code", "code"),
    )
