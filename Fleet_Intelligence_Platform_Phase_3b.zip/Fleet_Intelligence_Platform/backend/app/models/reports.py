import uuid
from datetime import datetime

from sqlalchemy import (
    Boolean,
    CheckConstraint,
    DateTime,
    ForeignKey,
    Index,
    Integer,
    SmallInteger,
    String,
    Text,
    UniqueConstraint,
    text,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database.base import Base
from app.database.mixins import TimestampMixin, UUIDPrimaryKeyMixin
from app.models.enums import ReportStatus
from app.models.files import ImportProfile, UploadedFile


class Report(UUIDPrimaryKeyMixin, TimestampMixin, Base):
    """One version of one monthly report.

    The reporting year and month are stored explicitly (confirmed by an administrator),
    never inferred from Excel date formatting. A replacement is a NEW row with a higher
    version that points at the row it replaces; the old row is kept and marked superseded.
    """

    __tablename__ = "reports"

    year: Mapped[int] = mapped_column(SmallInteger, nullable=False)
    month: Mapped[int] = mapped_column(SmallInteger, nullable=False)
    version: Mapped[int] = mapped_column(Integer, nullable=False, server_default="1")
    status: Mapped[str] = mapped_column(
        String(20),
        nullable=False,
        default=ReportStatus.DRAFT.value,
        server_default="draft",
    )
    is_current: Mapped[bool] = mapped_column(Boolean, nullable=False, server_default="false")
    days_in_month: Mapped[int] = mapped_column(SmallInteger, nullable=False)
    source_file_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("uploaded_files.id", ondelete="RESTRICT"), nullable=False
    )
    import_profile_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("import_profiles.id", ondelete="RESTRICT")
    )
    supersedes_report_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("reports.id", ondelete="RESTRICT")
    )
    superseded_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    replacement_reason: Mapped[str | None] = mapped_column(Text)
    confirmed_by_user_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("users.id", ondelete="RESTRICT")
    )
    confirmed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    notes: Mapped[str | None] = mapped_column(Text)

    source_file: Mapped[UploadedFile] = relationship(UploadedFile)
    import_profile: Mapped[ImportProfile | None] = relationship(ImportProfile)
    supersedes: Mapped["Report | None"] = relationship(
        remote_side="Report.id", back_populates="superseded_by"
    )
    superseded_by: Mapped[list["Report"]] = relationship(back_populates="supersedes")

    __table_args__ = (
        UniqueConstraint("year", "month", "version", name="uq_reports_year_month_version"),
        CheckConstraint("month BETWEEN 1 AND 12", name="month_range"),
        CheckConstraint("year BETWEEN 2000 AND 2100", name="year_range"),
        CheckConstraint("version >= 1", name="version_positive"),
        CheckConstraint("days_in_month BETWEEN 28 AND 31", name="days_in_month_range"),
        CheckConstraint(
            "status IN ('draft', 'active', 'superseded', 'failed')", name="status"
        ),
        CheckConstraint("NOT is_current OR status = 'active'", name="current_must_be_active"),
        CheckConstraint(
            "(status = 'superseded') = (superseded_at IS NOT NULL)",
            name="superseded_consistency",
        ),
        CheckConstraint(
            "supersedes_report_id IS NULL OR supersedes_report_id <> id",
            name="not_self_superseding",
        ),
        Index(
            "uq_reports_current_year_month",
            "year",
            "month",
            unique=True,
            postgresql_where=text("is_current"),
        ),
        Index("ix_reports_source_file_id", "source_file_id"),
        Index("ix_reports_supersedes_report_id", "supersedes_report_id"),
    )
