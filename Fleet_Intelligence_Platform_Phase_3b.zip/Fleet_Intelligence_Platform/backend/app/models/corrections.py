import uuid
from datetime import datetime
from typing import Any

from sqlalchemy import (
    BigInteger,
    CheckConstraint,
    DateTime,
    ForeignKey,
    Index,
    String,
    Text,
    UniqueConstraint,
    func,
)
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database.base import Base
from app.database.mixins import BigIntPrimaryKeyMixin
from app.models.enums import CorrectionType


class DataCorrection(BigIntPrimaryKeyMixin, Base):
    """Append-only correction history (a trigger rejects UPDATE and DELETE).

    Original imported values are never overwritten: the effective value of a field is
    derived later from the original plus the latest non-reversed correction.
    Reverting a correction INSERTS a new row with correction_type = 'reversal' that
    references the reverted row; nothing earlier is modified.
    """

    __tablename__ = "data_corrections"

    report_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("reports.id", ondelete="RESTRICT")
    )
    report_vehicle_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("report_vehicles.id", ondelete="RESTRICT")
    )
    target_table: Mapped[str] = mapped_column(String(50), nullable=False)
    target_id: Mapped[str] = mapped_column(String(64), nullable=False)
    field_name: Mapped[str] = mapped_column(String(100), nullable=False)
    original_value: Mapped[Any | None] = mapped_column(JSONB(none_as_null=True))
    corrected_value: Mapped[Any | None] = mapped_column(JSONB(none_as_null=True))
    reason: Mapped[str] = mapped_column(Text, nullable=False)
    correction_type: Mapped[str] = mapped_column(
        String(20),
        nullable=False,
        default=CorrectionType.CORRECTION.value,
        server_default="correction",
    )
    corrected_by_user_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("users.id", ondelete="RESTRICT"), nullable=False
    )
    corrected_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    reverses_correction_id: Mapped[int | None] = mapped_column(
        BigInteger, ForeignKey("data_corrections.id", ondelete="RESTRICT")
    )
    supersedes_correction_id: Mapped[int | None] = mapped_column(
        BigInteger, ForeignKey("data_corrections.id", ondelete="RESTRICT")
    )

    reverses: Mapped["DataCorrection | None"] = relationship(
        remote_side="DataCorrection.id", foreign_keys=[reverses_correction_id]
    )
    supersedes: Mapped["DataCorrection | None"] = relationship(
        remote_side="DataCorrection.id", foreign_keys=[supersedes_correction_id]
    )

    __table_args__ = (
        UniqueConstraint(
            "reverses_correction_id", name="uq_data_corrections_reverses_correction_id"
        ),
        CheckConstraint(
            "target_table IN ('daily_km', 'daily_status', 'report_vehicles',"
            " 'monthly_financials', 'vehicles')",
            name="target_table",
        ),
        CheckConstraint("correction_type IN ('correction', 'reversal')", name="correction_type"),
        CheckConstraint(
            "(correction_type = 'reversal') = (reverses_correction_id IS NOT NULL)",
            name="reversal_links_original",
        ),
        CheckConstraint("length(btrim(reason)) > 0", name="reason_not_blank"),
        CheckConstraint(
            "reverses_correction_id IS NULL OR reverses_correction_id <> id",
            name="not_self_reversing",
        ),
        CheckConstraint(
            "supersedes_correction_id IS NULL OR supersedes_correction_id <> id",
            name="not_self_superseding",
        ),
        Index("ix_data_corrections_target", "target_table", "target_id"),
        Index("ix_data_corrections_report_vehicle_id", "report_vehicle_id"),
        Index("ix_data_corrections_report_id", "report_id"),
        Index("ix_data_corrections_corrected_at", "corrected_at"),
        Index("ix_data_corrections_corrected_by_user_id", "corrected_by_user_id"),
    )
