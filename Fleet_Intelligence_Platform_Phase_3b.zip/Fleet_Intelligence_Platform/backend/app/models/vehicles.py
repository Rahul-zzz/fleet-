import uuid
from typing import Any

from sqlalchemy import (
    Boolean,
    CheckConstraint,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database.base import Base
from app.database.mixins import CreatedAtMixin, TimestampMixin, UUIDPrimaryKeyMixin
from app.models.reports import Report


class Vehicle(UUIDPrimaryKeyMixin, TimestampMixin, Base):
    """Vehicle identity. ``reg_no`` is the canonical registration number (the only
    matching key across sheets and months). Route and type here are the latest known
    master values; what a given month's report said lives in report_vehicles.
    """

    __tablename__ = "vehicles"

    reg_no: Mapped[str] = mapped_column(String(20), nullable=False)
    route: Mapped[str | None] = mapped_column(String(200))
    vehicle_type: Mapped[str | None] = mapped_column(String(100))
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, server_default="true")
    notes: Mapped[str | None] = mapped_column(Text)

    report_vehicles: Mapped[list["ReportVehicle"]] = relationship(back_populates="vehicle")

    __table_args__ = (
        UniqueConstraint("reg_no", name="uq_vehicles_reg_no"),
        CheckConstraint("reg_no ~ '^[A-Z0-9]{4,20}$'", name="reg_no_canonical"),
    )


class ReportVehicle(UUIDPrimaryKeyMixin, CreatedAtMixin, Base):
    """A vehicle's snapshot inside one report, as imported (immutable; fixes go through
    data_corrections). Later changes to the vehicle master never alter old reports.
    """

    __tablename__ = "report_vehicles"

    report_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("reports.id", ondelete="RESTRICT"), nullable=False
    )
    vehicle_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("vehicles.id", ondelete="RESTRICT"), nullable=False
    )
    reg_no_as_imported: Mapped[str] = mapped_column(String(50), nullable=False)
    route: Mapped[str | None] = mapped_column(String(200))
    vehicle_type: Mapped[str | None] = mapped_column(String(100))
    source_sheet: Mapped[str | None] = mapped_column(String(255))
    source_row: Mapped[int | None] = mapped_column(Integer)
    remarks: Mapped[str | None] = mapped_column(Text)
    attributes: Mapped[dict[str, Any] | None] = mapped_column(JSONB(none_as_null=True))

    report: Mapped[Report] = relationship(Report)
    vehicle: Mapped[Vehicle] = relationship(back_populates="report_vehicles")

    __table_args__ = (
        UniqueConstraint(
            "report_id", "vehicle_id", name="uq_report_vehicles_report_id_vehicle_id"
        ),
        Index("ix_report_vehicles_vehicle_id", "vehicle_id"),
    )
