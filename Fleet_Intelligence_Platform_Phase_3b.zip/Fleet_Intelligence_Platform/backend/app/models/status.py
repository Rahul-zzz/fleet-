import uuid

from sqlalchemy import (
    Boolean,
    CheckConstraint,
    ForeignKey,
    Index,
    SmallInteger,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database.base import Base
from app.database.mixins import (
    BigIntPrimaryKeyMixin,
    CreatedAtMixin,
    IntPrimaryKeyMixin,
    TimestampMixin,
)


class StatusDefinition(IntPrimaryKeyMixin, TimestampMixin, Base):
    """A canonical vehicle status and how it is classified.

    ``code`` never changes. ``category`` is configurable; every change is appended to
    ``status_definition_history``. Definitions are deactivated, never deleted.
    """

    __tablename__ = "status_definitions"

    code: Mapped[str] = mapped_column(String(50), nullable=False)
    display_name: Mapped[str] = mapped_column(String(100), nullable=False)
    category: Mapped[str] = mapped_column(String(20), nullable=False)
    sort_order: Mapped[int] = mapped_column(SmallInteger, nullable=False, server_default="0")
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, server_default="true")
    is_system: Mapped[bool] = mapped_column(Boolean, nullable=False, server_default="false")
    description: Mapped[str | None] = mapped_column(Text)

    aliases: Mapped[list["StatusAlias"]] = relationship(back_populates="definition")
    history: Mapped[list["StatusDefinitionHistory"]] = relationship(
        back_populates="definition"
    )

    __table_args__ = (
        UniqueConstraint("code", name="uq_status_definitions_code"),
        UniqueConstraint("display_name", name="uq_status_definitions_display_name"),
        CheckConstraint("code ~ '^[a-z0-9_]+$'", name="code_format"),
        CheckConstraint(
            "category IN ('utilized', 'unutilized', 'unclassified')", name="category"
        ),
    )


class StatusAlias(IntPrimaryKeyMixin, TimestampMixin, Base):
    """A spelling (normalized: lower case, single spaces) that maps to a definition."""

    __tablename__ = "status_aliases"

    status_definition_id: Mapped[int] = mapped_column(
        ForeignKey("status_definitions.id", ondelete="RESTRICT"), nullable=False
    )
    alias_normalized: Mapped[str] = mapped_column(String(100), nullable=False)
    alias_display: Mapped[str] = mapped_column(String(100), nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, server_default="true")
    created_by_user_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("users.id", ondelete="RESTRICT")
    )

    definition: Mapped[StatusDefinition] = relationship(back_populates="aliases")

    __table_args__ = (
        UniqueConstraint("alias_normalized", name="uq_status_aliases_alias_normalized"),
        CheckConstraint(
            "alias_normalized = lower(btrim(alias_normalized)) AND length(alias_normalized) > 0",
            name="alias_normalized_format",
        ),
        Index("ix_status_aliases_status_definition_id", "status_definition_id"),
    )


class StatusDefinitionHistory(BigIntPrimaryKeyMixin, CreatedAtMixin, Base):
    """Append-only record of every change made to a status definition."""

    __tablename__ = "status_definition_history"

    status_definition_id: Mapped[int] = mapped_column(
        ForeignKey("status_definitions.id", ondelete="RESTRICT"), nullable=False
    )
    field_name: Mapped[str] = mapped_column(String(50), nullable=False)
    old_value: Mapped[str | None] = mapped_column(String(100))
    new_value: Mapped[str | None] = mapped_column(String(100))
    changed_by_user_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("users.id", ondelete="RESTRICT")
    )
    reason: Mapped[str | None] = mapped_column(Text)

    definition: Mapped[StatusDefinition] = relationship(back_populates="history")

    __table_args__ = (
        Index(
            "ix_status_definition_history_definition_created",
            "status_definition_id",
            "created_at",
        ),
    )
