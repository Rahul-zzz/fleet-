import uuid
from datetime import datetime
from typing import Any

from sqlalchemy import (
    Boolean,
    CheckConstraint,
    DateTime,
    ForeignKey,
    Index,
    String,
    Text,
    func,
    text,
)
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column

from app.database.base import Base
from app.database.mixins import BigIntPrimaryKeyMixin, TimestampMixin


class VehicleMetric(BigIntPrimaryKeyMixin, TimestampMixin, Base):
    """Cached, derived per-vehicle metrics for one report (structure only in Phase 3b).

    Rows are derived data and can always be rebuilt. When source data, corrections or
    configuration change, the current row is marked not-current (invalidated) and a new
    row is added by the future Metrics Engine. This phase contains no calculation logic.
    """

    __tablename__ = "vehicle_metrics"

    report_vehicle_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("report_vehicles.id", ondelete="RESTRICT"), nullable=False
    )
    calc_version: Mapped[str] = mapped_column(String(50), nullable=False)
    metric_values: Mapped[dict[str, Any]] = mapped_column(JSONB, nullable=False)
    provenance: Mapped[dict[str, Any] | None] = mapped_column(JSONB(none_as_null=True))
    inputs_fingerprint: Mapped[str | None] = mapped_column(String(64))
    calculated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    is_current: Mapped[bool] = mapped_column(Boolean, nullable=False, server_default="true")
    invalidated_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    invalidation_reason: Mapped[str | None] = mapped_column(Text)

    __table_args__ = (
        CheckConstraint("NOT is_current OR invalidated_at IS NULL", name="current_not_invalidated"),
        Index(
            "uq_vehicle_metrics_current",
            "report_vehicle_id",
            unique=True,
            postgresql_where=text("is_current"),
        ),
        Index("ix_vehicle_metrics_report_vehicle_calc", "report_vehicle_id", "calc_version"),
    )


class ReportMetric(BigIntPrimaryKeyMixin, TimestampMixin, Base):
    """Cached, derived fleet-level metrics for one report (structure only)."""

    __tablename__ = "report_metrics"

    report_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("reports.id", ondelete="RESTRICT"), nullable=False
    )
    calc_version: Mapped[str] = mapped_column(String(50), nullable=False)
    metric_values: Mapped[dict[str, Any]] = mapped_column(JSONB, nullable=False)
    provenance: Mapped[dict[str, Any] | None] = mapped_column(JSONB(none_as_null=True))
    inputs_fingerprint: Mapped[str | None] = mapped_column(String(64))
    calculated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    is_current: Mapped[bool] = mapped_column(Boolean, nullable=False, server_default="true")
    invalidated_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    invalidation_reason: Mapped[str | None] = mapped_column(Text)

    __table_args__ = (
        CheckConstraint("NOT is_current OR invalidated_at IS NULL", name="current_not_invalidated"),
        Index(
            "uq_report_metrics_current",
            "report_id",
            unique=True,
            postgresql_where=text("is_current"),
        ),
        Index("ix_report_metrics_report_calc", "report_id", "calc_version"),
    )
