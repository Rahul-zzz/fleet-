"""Allowed values for constrained columns.

The database stores these as plain strings protected by CHECK constraints (not native
PostgreSQL ENUM types), which keeps later migrations simple. The same values are
written literally in the CHECK constraints and in the Alembic migration; a unit test
keeps them in sync.
"""
from enum import StrEnum


class UserRole(StrEnum):
    ADMIN = "admin"
    ANALYST = "analyst"


class UploadStatus(StrEnum):
    UPLOADED = "uploaded"
    ANALYZED = "analyzed"
    COMMITTED = "committed"
    REJECTED = "rejected"
    FAILED = "failed"


class ReportStatus(StrEnum):
    DRAFT = "draft"
    ACTIVE = "active"
    SUPERSEDED = "superseded"
    FAILED = "failed"


class IssueSeverity(StrEnum):
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"


class KmDataState(StrEnum):
    ACTUAL = "actual"  # numeric reading greater than zero
    REPORTED_ZERO = "reported_zero"  # device reported 0 km
    GPS_OFFLINE = "gps_offline"  # source said "Offline"; never zero
    MISSING = "missing"  # no reading in the source; never zero
    INVALID = "invalid"  # present but not a valid number


class StatusMatchState(StrEnum):
    RECOGNIZED = "recognized"
    UNRECOGNIZED = "unrecognized"
    MISSING = "missing"


class StatusCategory(StrEnum):
    UTILIZED = "utilized"
    UNUTILIZED = "unutilized"
    UNCLASSIFIED = "unclassified"


class CorrectionType(StrEnum):
    CORRECTION = "correction"
    REVERSAL = "reversal"


class CorrectionTarget(StrEnum):
    DAILY_KM = "daily_km"
    DAILY_STATUS = "daily_status"
    REPORT_VEHICLES = "report_vehicles"
    MONTHLY_FINANCIALS = "monthly_financials"
    VEHICLES = "vehicles"


class MessageRole(StrEnum):
    USER = "user"
    ASSISTANT = "assistant"
    TOOL = "tool"
    SYSTEM = "system"


class MessageChannel(StrEnum):
    TEXT = "text"
    VOICE = "voice"


class AiReportKind(StrEnum):
    MONTHLY_UTILIZATION = "monthly_utilization"
    VEHICLE_PERFORMANCE = "vehicle_performance"
    UNUTILIZED_VEHICLE = "unutilized_vehicle"
    FLEET_EFFICIENCY = "fleet_efficiency"
    EXECUTIVE_SUMMARY = "executive_summary"
