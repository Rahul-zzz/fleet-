import uuid
from dataclasses import dataclass

from sqlalchemy import select

from app.models.enums import StatusCategory, StatusMatchState
from app.models.status import StatusAlias, StatusDefinition, StatusDefinitionHistory
from app.repositories.base import Repository
from app.utils.status_text import normalize_status_text


@dataclass(frozen=True)
class StatusResolution:
    """Result of matching one imported status cell. Unknown text is never classified."""

    match_state: str
    definition: StatusDefinition | None = None
    alias: StatusAlias | None = None


class StatusRepository(Repository):
    def list_definitions(self, active_only: bool = False) -> list[StatusDefinition]:
        query = select(StatusDefinition).order_by(StatusDefinition.sort_order, StatusDefinition.id)
        if active_only:
            query = query.where(StatusDefinition.is_active.is_(True))
        return list(self.session.scalars(query))

    def get_by_code(self, code: str) -> StatusDefinition | None:
        return self.session.scalar(select(StatusDefinition).where(StatusDefinition.code == code))

    def resolve(self, source_text: object) -> StatusResolution:
        """missing: blank cell. recognized: matches an active alias of an active definition.
        unrecognized: anything else (kept as imported, never auto-classified)."""
        normalized = normalize_status_text(source_text)
        if normalized is None:
            return StatusResolution(StatusMatchState.MISSING.value)
        alias = self.session.scalar(
            select(StatusAlias).where(
                StatusAlias.alias_normalized == normalized, StatusAlias.is_active.is_(True)
            )
        )
        if alias is not None and alias.definition.is_active:
            return StatusResolution(StatusMatchState.RECOGNIZED.value, alias.definition, alias)
        return StatusResolution(StatusMatchState.UNRECOGNIZED.value)

    def set_category(
        self,
        definition: StatusDefinition,
        new_category: str,
        changed_by_user_id: uuid.UUID | None,
        reason: str | None = None,
    ) -> StatusDefinitionHistory | None:
        """Change a classification and append a history row. Returns None if unchanged.

        Definitions are never deleted or renamed through this method.
        """
        if new_category not in {c.value for c in StatusCategory}:
            raise ValueError(f"unknown status category: {new_category!r}")
        if definition.category == new_category:
            return None
        history = StatusDefinitionHistory(
            status_definition_id=definition.id,
            field_name="category",
            old_value=definition.category,
            new_value=new_category,
            changed_by_user_id=changed_by_user_id,
            reason=reason,
        )
        definition.category = new_category
        self.session.add(history)
        self.session.flush()
        return history
