from sqlalchemy import select

from app.models.vehicles import Vehicle
from app.repositories.base import Repository
from app.utils.registration import normalize_registration


class VehicleRepository(Repository):
    def get_by_reg_no(self, reg_no: object) -> Vehicle | None:
        canonical = normalize_registration(reg_no)
        return self.session.scalar(select(Vehicle).where(Vehicle.reg_no == canonical))

    def get_or_create(
        self,
        reg_no: object,
        route: str | None = None,
        vehicle_type: str | None = None,
    ) -> tuple[Vehicle, bool]:
        """Return (vehicle, created). Matching uses only the canonical registration number.

        Existing master values are not overwritten here.
        """
        existing = self.get_by_reg_no(reg_no)
        if existing is not None:
            return existing, False
        vehicle = Vehicle(
            reg_no=normalize_registration(reg_no), route=route, vehicle_type=vehicle_type
        )
        self.session.add(vehicle)
        self.session.flush()
        return vehicle, True
