import uuid
from typing import Any

from sqlalchemy import select

from app.models.corrections import DataCorrection
from app.models.enums import CorrectionTarget, CorrectionType
from app.repositories.base import Repository


class CorrectionError(ValueError):
    """A correction request that must be refused."""


class CorrectionRepository(Repository):
    def add_correction(
        self,
        *,
        target_table: str,
        target_id: str,
        field_name: str,
        original_value: Any,
        corrected_value: Any,
        reason: str,
        corrected_by_user_id: uuid.UUID,
        report_id: uuid.UUID | None = None,
        report_vehicle_id: uuid.UUID | None = None,
        supersedes_correction_id: int | None = None,
    ) -> DataCorrection:
        """Append a correction. The imported value is NOT touched anywhere."""
        if target_table not in {t.value for t in CorrectionTarget}:
            raise CorrectionError(f"unsupported correction target: {target_table!r}")
        if not reason or not reason.strip():
            raise CorrectionError("a reason is required")
        correction = DataCorrection(
            report_id=report_id,
            report_vehicle_id=report_vehicle_id,
            target_table=target_table,
            target_id=str(target_id),
            field_name=field_name,
            original_value=original_value,
            corrected_value=corrected_value,
            reason=reason.strip(),
            correction_type=CorrectionType.CORRECTION.value,
            corrected_by_user_id=corrected_by_user_id,
            supersedes_correction_id=supersedes_correction_id,
        )
        self.session.add(correction)
        self.session.flush()
        return correction

    def reverse(
        self, correction_id: int, reason: str, reversed_by_user_id: uuid.UUID
    ) -> DataCorrection:
        """Revert a correction by appending a reversal row. The earlier row is unchanged.

        Only a normal correction can be reverted, and only once (the database also
        enforces this with a unique constraint). To change a value again, add a new
        correction.
        """
        original = self.session.get(DataCorrection, correction_id)
        if original is None:
            raise CorrectionError(f"correction {correction_id} does not exist")
        if original.correction_type != CorrectionType.CORRECTION.value:
            raise CorrectionError("a reversal cannot be reversed; add a new correction instead")
        already = self.session.scalar(
            select(DataCorrection.id).where(DataCorrection.reverses_correction_id == original.id)
        )
        if already is not None:
            raise CorrectionError(f"correction {correction_id} was already reversed")
        if not reason or not reason.strip():
            raise CorrectionError("a reason is required")
        reversal = DataCorrection(
            report_id=original.report_id,
            report_vehicle_id=original.report_vehicle_id,
            target_table=original.target_table,
            target_id=original.target_id,
            field_name=original.field_name,
            original_value=original.corrected_value,
            corrected_value=original.original_value,
            reason=reason.strip(),
            correction_type=CorrectionType.REVERSAL.value,
            corrected_by_user_id=reversed_by_user_id,
            reverses_correction_id=original.id,
        )
        self.session.add(reversal)
        self.session.flush()
        return reversal
