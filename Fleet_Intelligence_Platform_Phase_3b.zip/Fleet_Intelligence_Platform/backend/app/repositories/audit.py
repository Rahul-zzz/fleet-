from typing import Any

from app.models.audit import AuditLog
from app.models.user import User
from app.repositories.base import Repository


class AuditRepository(Repository):
    def record(
        self,
        action: str,
        entity_type: str,
        entity_id: str | None = None,
        actor: User | None = None,
        before: dict[str, Any] | None = None,
        after: dict[str, Any] | None = None,
        details: dict[str, Any] | None = None,
        ip_address: str | None = None,
        request_id: str | None = None,
    ) -> AuditLog:
        """Append one audit row. before/after/details must already be JSON-serializable."""
        entry = AuditLog(
            actor_user_id=actor.id if actor else None,
            actor_email=actor.email if actor else None,
            action=action,
            entity_type=entity_type,
            entity_id=entity_id,
            before_data=before,
            after_data=after,
            details=details,
            ip_address=ip_address,
            request_id=request_id,
        )
        self.session.add(entry)
        self.session.flush()
        return entry
