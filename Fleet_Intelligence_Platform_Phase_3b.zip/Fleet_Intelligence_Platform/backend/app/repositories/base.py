from sqlalchemy.orm import Session


class Repository:
    """Repositories receive a Session and never commit: the caller owns the transaction."""

    def __init__(self, session: Session) -> None:
        self.session = session
