from pathlib import Path

from sqlalchemy import inspect, text
from sqlalchemy.orm import Session

import app.models  # noqa: F401  (registers all tables on Base.metadata)
from app.database.base import Base
from app.schemas.schema_status import SchemaStatusResponse

BACKEND_DIR = Path(__file__).resolve().parents[2]


def evaluate_schema_status(
    current_revision: str | None,
    head_revision: str | None,
    expected_tables: int,
    present_tables: int,
) -> str:
    """Pure decision logic (unit-tested without a database)."""
    if current_revision is None:
        return "not_initialized"
    if head_revision is not None and current_revision != head_revision:
        return "outdated"
    if present_tables < expected_tables:
        return "incomplete"
    return "ok"


def _head_revision() -> str | None:
    """The newest migration shipped with this backend, or None if it cannot be read."""
    try:
        from alembic.config import Config
        from alembic.script import ScriptDirectory

        config = Config(str(BACKEND_DIR / "alembic.ini"))
        return ScriptDirectory.from_config(config).get_current_head()
    except Exception:  # missing alembic files in a deployment must not break the check
        return None


def get_schema_status(db: Session) -> SchemaStatusResponse:
    """Compare the database with the models and migrations. Raises SQLAlchemyError if
    the database cannot be reached (the API layer turns that into a generic 503)."""
    bind = db.get_bind()
    present = set(inspect(bind).get_table_names())
    current: str | None = None
    if "alembic_version" in present:
        current = db.execute(text("SELECT version_num FROM alembic_version")).scalar()
    expected = set(Base.metadata.tables)
    head = _head_revision()
    present_expected = len(expected & present)
    return SchemaStatusResponse(
        status=evaluate_schema_status(current, head, len(expected), present_expected),
        current_revision=current,
        head_revision=head,
        expected_table_count=len(expected),
        present_table_count=present_expected,
    )

