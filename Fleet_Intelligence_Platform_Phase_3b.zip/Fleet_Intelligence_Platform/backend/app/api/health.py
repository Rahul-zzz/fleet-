import logging
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import text
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session

from app.core.config import Settings, get_settings
from app.database.session import get_db
from app.schemas.health import DatabaseHealthResponse, HealthResponse
from app.schemas.schema_status import SchemaStatusResponse
from app.services.schema_status import get_schema_status

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/health", tags=["health"])


@router.get("", response_model=HealthResponse, summary="API liveness check")
def health(settings: Settings = Depends(get_settings)) -> HealthResponse:
    return HealthResponse(
        status="ok",
        service=settings.app_name,
        environment=settings.environment,
        version=settings.app_version,
        timestamp=datetime.now(timezone.utc).isoformat(),
    )


@router.get(
    "/db",
    response_model=DatabaseHealthResponse,
    summary="Database connectivity check",
)
def health_db(db: Session = Depends(get_db)) -> DatabaseHealthResponse:
    try:
        db.execute(text("SELECT 1"))
    except SQLAlchemyError:
        # Details go to the server log only, never to the client.
        logger.exception("Database health check failed")
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Database unavailable",
        )
    return DatabaseHealthResponse(status="ok", database="connected")


@router.get(
    "/schema",
    response_model=SchemaStatusResponse,
    summary="Database schema / migration status",
)
def health_schema(db: Session = Depends(get_db)) -> SchemaStatusResponse:
    """Tells you whether the database is migrated. Returns revisions and table COUNTS
    only: no table names, credentials or error details."""
    try:
        return get_schema_status(db)
    except SQLAlchemyError:
        logger.exception("Schema status check failed")
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Database unavailable",
        )
